#include <limits> // for infinity
#include "laser_processing.h"
#include <iostream>

LaserProcessing::LaserProcessing(sensor_msgs::LaserScan laserScan, geometry_msgs::Pose robot0Pose):
    laserScan_(laserScan), robot0Pose_(robot0Pose)
{

}


void LaserProcessing::newScan(sensor_msgs::LaserScan laserScan, geometry_msgs::Pose robot0Pose){
    laserScan_=laserScan;
    robot0Pose_=robot0Pose;
}



bool LaserProcessing::detectPoseHighIntensity(geometry_msgs::Pose robot1Pose){


    geometry_msgs::Pose pose;
    for(int i=0; i<laserScan_.ranges.size(); i++)
    {
      if(laserScan_.intensities.at(i)>0.5)
      {
        pose=polarToCart(i);
//        ROS_INFO_STREAM("Test position: "<< pose.position.x<<","<<pose.position.y);
//        ROS_INFO_STREAM("Actual position: "<<robot1Pose.position.x<<","<<robot1Pose.position.y);
        double x=pose.position.x-robot1Pose.position.x;
        double y=pose.position.y-robot1Pose.position.y;
        if(((x>-1) && (x<1)) && ((y>-1) && (y<1)))
        {
          return true;
        }
      }
    }
    return false;

}

 bool LaserProcessing::detectWall()
 {
   double laser_readings_=laserScan_.range_max;
   for(unsigned int i=0; i<laserScan_.ranges.size(); i++)
   {
     if(laserScan_.ranges.at(i)<laser_readings_)
     {
       laser_readings_=laserScan_.ranges.at(i);
     }
   }
   if(laser_readings_<=0.5)
   {
     return true;
   }
   else {
     return false;
   }
 }



geometry_msgs::Pose LaserProcessing::polarToCart(unsigned int index)
{
    float robotangle=tf::getYaw(robot0Pose_.orientation);
    float angle = laserScan_.angle_min + laserScan_.angle_increment*index;// + angle_range/2;
    float range = laserScan_.ranges.at(index);
    geometry_msgs::Pose cart;
    cart.position.x = static_cast<double>(range*cos(angle+robotangle));
    cart.position.y = static_cast<double>(range*sin(angle+robotangle));
    cart.orientation.z=0;
    return cart;
}

