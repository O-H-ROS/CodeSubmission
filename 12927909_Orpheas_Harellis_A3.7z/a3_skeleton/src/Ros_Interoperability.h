
/**
 * @brief Main Access Port for Assignment 3
 * @note  Project 4 Personal Assistant (Trajectory Following)
 * @note  The code includes:
 * @note  1. Subscription to topics
 * @note  2. Threading
 * @note  3. Running of a seperate thread
 * @note  Please add the /robot_0/following and /robot_1/following topic on rviz to visualise the markers, or simply run the provided rviz config file provided
 * @author Orpheas Harellis 12927909
 * @date November 2021
 */


#include <sstream>
#include <iostream>
#include <string>

#include <thread>
#include <mutex>
#include <chrono>
#include <queue>
#include <atomic>

#include "ros/ros.h"
#include "tf/transform_datatypes.h" //To use getYaw function from the quaternion of orientation

//! Messages utilised within this robot following another robot project are here
#include "sensor_msgs/LaserScan.h"
#include "nav_msgs/Odometry.h"
#include "nav_msgs/OccupancyGrid.h"
#include "visualization_msgs/MarkerArray.h"
#include "geometry_msgs/PoseArray.h"


//! All the messages for all projects are here
#include "project_setup/FaceGoal.h"
#include "project_setup/DetectParking.h"
#include "project_setup/RequestGoal.h"
#include "std_srvs/Trigger.h"



//! The class we have developed included here in our node
#include "grid_processing.h"
#include "laser_processing.h"


class RosInteroperability{

public:
  /*! @brief Sample constructor.
   *
   *  Will take the node handle and initialise the callbacks and internal variables
   */
    RosInteroperability(ros::NodeHandle nh);

  /*! @brief Sample destructor.
   */
    ~RosInteroperability();

  /*! @brief Odometry Callback for Robot 0
   *
   *  @param nav_msgs::OdometryConstPtr - The odometry message
   *  @note This function and the declaration are ROS specific
   */
    void odomCallback_robot0(const nav_msgs::OdometryConstPtr& msg);

    /*! @brief Odometry Callback for Robot 1
     *
     *  @param nav_msgs::OdometryConstPtr - The odometry message
     *  @note This function and the declaration are ROS specific
     */
      void odomCallback_robot1(const nav_msgs::OdometryConstPtr& msg);

  /*! @brief LaserScan Callback
   *
   *  @param sensor_msgs::LaserScanConstPtr - The laserscan message
   *  @note This function and the declaration are ROS specific
   */
    void laserCallback(const sensor_msgs::LaserScanConstPtr& msg);

  /*! @brief OccupancyGrid Callback
    *
    *  @param nav_msgs::OccupancyGridPtr
    *  @note This function and the declaration are ROS specific
    */
     void occupancyGridCallback(const nav_msgs::OccupancyGridPtr & msg);

  /*! @brief seperate thread.
   *
   *  The main processing thread that will run continously and utilise the data
   *  When data needs to be combined then running a thread seperate to callback will guarantee data is processed
   */
    void seperateThread(); 



private:



    /*! @brief Function that checks whether robot 0 is stationary
     *  @return bool - Will return true to indicate the robot is stationary
     */
    bool CheckIfStationary();

    /*! @brief Function that checks whether robot 1 is stationary
     *  @return bool - Will return true to indicate the robot is stationary
     */
    bool CheckIfStationaryLeader();

    /*! @brief Function that passes the velocity readings of Robot 0 into private variables, to be assessed within CheckIfStationary functions
     *  @param geometry_msgs::Twist& msg
     *  @note This function and the declaration are ROS specific
     */
    void filterVelocity(const geometry_msgs::Twist& msg);

    /*! @brief Function that passes the velocity readings of Robot 1 into private variables, to be assessed within CheckIfStationary functions
     *  @param geometry_msgs::Twist& msg
     *  @note This function and the declaration are ROS specific
     */
    void filterVelocityLeader(const geometry_msgs::Twist& msg);

    /*! @brief Background timer/counter for when robot 0 is stationary
     */
    void feedData();

    /*! @brief Background timer/counter for when robot 1 is stationary
     */
    void feedDataLeader();

    /*! @brief Function that enables the velocity control of the robot
     *  @param geometry_msgs::PoseArray target goal pose
     *  @param geometry_msgs::PoseArray current robot pose
     */
    void moveRobot(geometry_msgs::PoseArray target_poses_, geometry_msgs::Pose pose);


    /*! @brief Creates a MarkerArray by adding a single ARROW marker to it, based on (pose)x,y position
     * of point supplied and color supplied, marker is in namespace "test",
     * @note We use pose for the markers especially for the arrows
     *
     *  @param geometry_msgs::Pose
     *  @param std_msgs::ColorRGBA color - the color (including transparency) that will be used
     *  @return MarkerArray
      */
    visualization_msgs::MarkerArray exportMarker(geometry_msgs::Pose robotPose,std_msgs::ColorRGBA color);

    /*! @brief Function that enables the robot to avoid obstacles by simply changing its position/angular velocity
     */
    void avoidObstacle();

    /*! @brief Function that generates a way point for the path publisher to utilise
     *  @param geometry_msgs::PoseArray target goal pose
     *  @return geometry_msgs::Pose of the generated way point
     */
    geometry_msgs::Pose generateWayPoint(geometry_msgs::Pose);



    struct PoseDataBuffer                 //!Thread safe container
    {
        geometry_msgs::Pose pose;
        std::mutex mtx;
    };

    struct OgMapBuffer                    //!Thread safe container
    {
        nav_msgs::OccupancyGrid grid;
        std::mutex mtx;
    };

    struct LaserDataBuffer                //!Thread safe container
    {
        sensor_msgs::LaserScan laserscan;
        std::mutex mtx;
    };

    ros::NodeHandle nh_;                        //! Node handle
    ros::Publisher viz_pub_;                    //! Visualisation Marker publisher
    ros::Publisher viz2_pub_,viz3_pub_;         //! Visualisation Marker publisher
    ros::Subscriber sub1_,sub2_,sub3_,sub4_,sub_,subLeader_; //! Subscribers
    ros::ServiceServer service_;                //! Advertised Service

    ros::Publisher path_pub_,pub;               //! Pose array publisher

    OgMapBuffer ogMapBuffer_;                   //! Container for occupancygrid data, so it's accessible elsewhere
    PoseDataBuffer poseDataBuffer_;             //! Container for pose data, so it's accessible elsewhere
    LaserDataBuffer laserDataBuffer_;           //! Container for laser data, so it's accessible elsewhere
    PoseDataBuffer robot_0;                     //! Container for pose data for robot 0, so it's accessible elsewhere
    PoseDataBuffer robot_1;                     //! Container for pose data for robot 1, so it's accessible elsewhere
    std::atomic<bool> exampleBool_;             //! Atomic bool can be used between threads, callback
    geometry_msgs::PoseArray target_poses_;     //! Container for poseArray data for the path planning node
    geometry_msgs::PoseArray target_poses2_;    //! Container for poseArray data for the path planning node
    geometry_msgs::PoseArray target_poses0_;    //! Container for poseArray data for the path planning node
    visualization_msgs::MarkerArray marker_array_;  //! Marker array for generating the markers
    visualization_msgs::MarkerArray marker_array2_; //! Marker array for generating the markers
    visualization_msgs::MarkerArray markerArray2;   //! Marker array for generating the markers
    int marker_counter=0;                       //! Private variable that stores the marker count
    bool robot0Enabled=false;                   //! Boolean to check whether the robot 0 has set a path towards robot 1
    geometry_msgs::Pose goalPose;               //! Position of interest for robot 1 (leader robot)
    ros::Timer timer;                           //! Timer to schedule the callback for the seconds being stationary counter for Robot 0
    ros::Timer timerLeader;                     //! Timer to schedule the callback for the seconds being stationary counter for Robot 1
    int eventDuration=50;                       //! Variable for the ros speed refresh rate
    float linX,angZ,linX1,angZ1;                //! Thread safe variables to store the incoming velocity readings
    double timePassed,timePassedLeader;         //! Thread safe variables to store the seconds the robots have been stationary for
    bool checkStationary,checkStationaryLeader; //! Boolean variables that contains the stationary status of the Robots
    geometry_msgs::Pose wayPoint1;              //! Way point pose
    geometry_msgs::Pose wayPoint2;              //! Way point pose
    geometry_msgs::Pose wayPoint0;              //! Way point pose
    bool advanceMode;                           //! Boolean variable that controls the mode of the simulation, True for Advanced Mode, False for Basic Mode
    bool wayP_1=false;                          //! Flag that controls the robot's interaction with various waypoints
    bool wayP_2=true;                           //! Flag that controls the robot's interaction with various waypoints
    bool wayP_0=false;                          //! Flag that controls the robot's interaction with various waypoints
    std_msgs::ColorRGBA goalColor,interimColor; //! Color properties for the markers (including transparency)
    geometry_msgs::Pose robot0pose;             //! Pose of Robot 0





};

