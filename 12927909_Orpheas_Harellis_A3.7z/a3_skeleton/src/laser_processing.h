#ifndef LASER_PROCESSING_H
#define LASER_PROCESSING_H


#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Pose.h>
#include <nav_msgs/Odometry.h>
#include <math.h>
#include <ros/console.h>
#include "tf/transform_datatypes.h"

/**
 * @brief Laser Processing class, for all the laser needs of the simulation
 * @author Orpheas Harellis 12927909
 * @date November 2021
 */

class LaserProcessing
{
public:
  /*! @brief Constructor that allocates internals
   *
   *  @param[in]    laserScan - laserScan to be processed
   */
  LaserProcessing(sensor_msgs::LaserScan laserScan, geometry_msgs::Pose robot0Pose);




   /*! @brief Detects whether the guider robot is within the laser field of view of the follower robot
   * In the pose, the position should be on the first readings
   * While the orientation should be
   * looking towards the next 3 readigs
   * @param[in] Robot 1 (leader) pose
   * @return bool - whether robot 0 can detect robot 1
   */
  bool detectPoseHighIntensity(geometry_msgs::Pose robot1Pose);


  /*! @brief Accepts a new laserScan
   *  @param[in]    laserScan  - laserScan to be processed
   */
  void newScan(sensor_msgs::LaserScan laserScan, geometry_msgs::Pose robot0Pose);

  /*! @brief Detects whether the robot is about to hit a wall
  *   @return bool - True or false
  */
  bool detectWall();

private:
  /*! @brief Returns the cartesian position of laser reading at specific index
   * converted from polar coordinats stored in the #laserScan_
   *  @param[in] index - the reading needing conversion
   *  @return position cartesian values
   */
   geometry_msgs::Pose polarToCart(unsigned int index);


private:
  sensor_msgs::LaserScan laserScan_;
  geometry_msgs::Pose robot0Pose_;


};

#endif // IMAGE_PROCESSING_H
