#include "Ros_Interoperability.h"



RosInteroperability::RosInteroperability(ros::NodeHandle nh)
    : nh_(nh)
{
  //Robot 0 subscribing topics
  //Subscribing to odometry
  sub1_ = nh_.subscribe("robot_0/odom", 1000, &RosInteroperability::odomCallback_robot0,this);
  //Subscribing to laser
  sub2_ = nh_.subscribe("robot_0/base_scan", 10, &RosInteroperability::laserCallback,this);
  //Subscribing to occupnacy grid
  sub3_ = nh_.subscribe("local_map/local_map", 1, &RosInteroperability::occupancyGridCallback,this);
  //Subscribing to cmd velocity
  sub_=nh.subscribe("/robot_0/cmd_vel",1000, &RosInteroperability::filterVelocity, this);


  //Robot 1 subscribing topics
  //Subscribing to odometry
  sub4_= nh_.subscribe("robot_1/odom", 1000, &RosInteroperability::odomCallback_robot1,this);
  //Subscribing to cmd velocity
  subLeader_=nh.subscribe("/robot_1/cmd_vel",1000, &RosInteroperability::filterVelocityLeader, this);

  //Timers to schedule the feed data callback to occur on a 1 second rate
  timer=nh_.createTimer(ros::Duration(1.0), std::bind(&RosInteroperability::feedData, this));
  timerLeader=nh_.createTimer(ros::Duration(1.0), std::bind(&RosInteroperability::feedDataLeader, this));

  //Publishing topic for robot velocity control
  pub=nh_.advertise<geometry_msgs::Twist>("/robot_0/cmd_vel",1);


  //Publishing topic for marker array
  viz_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("visualization_marker",3);
  viz2_pub_= nh_.advertise<visualization_msgs::MarkerArray>("/robot_0/following",3);
  viz3_pub_= nh_.advertise<visualization_msgs::MarkerArray>("/robot_1/following",3);

  //Publishing topic for robot path following
  path_pub_=nh_.advertise<geometry_msgs::PoseArray>("/robot_0/path",1);

  // The simulation features two modes, Basic and Advanced
  // In order to run the basic mode, type in the terminal "rosrun a3_12927909 a3_12927909_ex _advanceMode:=false"
  // In order to run the advanced mode, type in the terminal "rosrun a3_12927909 a3_12927909_ex _advanceMode:=true"
  ros::NodeHandle pn("~");
  pn.param<bool>("advanceMode", advanceMode, true);

  if(advanceMode==true)
  {
    ROS_INFO_STREAM("Advanced Mode enabled");
  }
  if(advanceMode==false){
    ROS_INFO_STREAM("Basic Mode enabled");
  }

}

RosInteroperability::~RosInteroperability()
{

}


// A callback for odometry for robot 0, locking and storing data
void RosInteroperability::odomCallback_robot0(const nav_msgs::OdometryConstPtr& msg)
{
    // We store a copy of the pose and lock a mutex when updating
    std::unique_lock<std::mutex> lck (robot_0.mtx);
    robot_0.pose = msg->pose.pose;

//    ROS_INFO_STREAM("Robot 0 **** x: " << robot_0.pose.position.x
//                << ",  y: " << robot_0.pose.position.y
//                << ",  yaw: "<< tf::getYaw(robot_0.pose.orientation));

}

// A callback for odometry for robot 1, locking and storing data
void RosInteroperability::odomCallback_robot1(const nav_msgs::OdometryConstPtr& msg)
{
    // We store a copy of the pose and lock a mutex when updating
    std::unique_lock<std::mutex> lck (robot_1.mtx);
    robot_1.pose = msg->pose.pose;
//    ROS_INFO_STREAM("Robot 1 **** x: " << robot_1.pose.position.x
//                << ",  y: " << robot_1.pose.position.y
//                << ",  yaw: "<< tf::getYaw(robot_1.pose.orientation));
}


void RosInteroperability::occupancyGridCallback(const nav_msgs::OccupancyGridPtr& msg)
{

  std::unique_lock<std::mutex> lck (ogMapBuffer_.mtx);
  ogMapBuffer_.grid = *msg;

}

void RosInteroperability::laserCallback(const sensor_msgs::LaserScanConstPtr& msg)
{

  std::unique_lock<std::mutex> lck (laserDataBuffer_.mtx);
  laserDataBuffer_.laserscan= *msg;
}


void RosInteroperability::seperateThread() {



    //! The thread runs at a current rate of eventDuration=1/50 Hz
    ros::Rate rate_limiter(eventDuration);

    //Implementing the gridproccessing and laserprocessing objects
    GridProcessing gridProcessing(ogMapBuffer_.grid);
    LaserProcessing LaserProcessing(laserDataBuffer_.laserscan,robot0pose);
    robot_1.pose.orientation.z=0;
    target_poses_.poses.push_back(robot_0.pose);
    rate_limiter.sleep();

    geometry_msgs::Pose waypointPose;

    //Unique flags to be used within the next few sections
    bool flag=true;
    bool flag2=false;
    bool goalBuffer=true;


    //Setting the color for the goal pose, green in colour
    goalColor.a=0.5;
    goalColor.r=0.0;
    goalColor.g=1.0;
    goalColor.b=0.0;

    //Setting the color for the interim pose, blue in colour
    interimColor.a=0.5;
    interimColor.r=0.0;
    interimColor.g=0.0;
    interimColor.b=1.0;

    //Unique marker id
    int id=0;

    //Pose for the waypoints
    geometry_msgs::Pose flagcheck;

    while (ros::ok()) {

        checkStationary=CheckIfStationary();
        checkStationaryLeader=CheckIfStationaryLeader();


        //Obtaining the robot 0 pose and storing into a new pose
        std::unique_lock<std::mutex> lck_r_0 (robot_0.mtx);
        geometry_msgs::Pose robot0pose=robot_0.pose;
        //robot0pose=robot_0.pose;
        lck_r_0.unlock();

        //Obtaining the robot 1 pose and storing into a new pose
        std::unique_lock<std::mutex> lck_r_1 (robot_1.mtx);
        geometry_msgs::Pose robot1pose=robot_1.pose;
        lck_r_1.unlock();

        //Getting the Grid
        std::unique_lock<std::mutex> lck_g (ogMapBuffer_.mtx);
        nav_msgs::OccupancyGrid grid = ogMapBuffer_.grid;
        gridProcessing.setGrid(grid);
        lck_g.unlock();

        //Getting the robot 0 laser scan
        std::unique_lock<std::mutex> lck_l_0 (laserDataBuffer_.mtx);
        sensor_msgs::LaserScan laser0scan=laserDataBuffer_.laserscan;
        LaserProcessing.newScan(laser0scan,robot0pose);
        lck_l_0.unlock();



        //  ROS_INFO_STREAM("Example checking [x,y]=[" << robot1pose.position.x << "," << robot1pose.position.y << "]" <<
        //            " to [x,y]=[" << robot0pose.position.x << "," << robot0pose.position.y << "]" );



        //Converting into robot centric coordinates and storing them in a pose
        geometry_msgs::Point testLocal;
        testLocal.x = robot1pose.position.x - robot0pose.position.x; //Global to robotic local
        testLocal.y = robot1pose.position.y - robot0pose.position.y;

        geometry_msgs::Pose testLocalPose;
        testLocalPose.position.x=testLocal.x;
        testLocalPose.position.y=testLocal.y;
        testLocalPose.position.z=0;

        //ROS_INFO_STREAM("Test checking [x,y]=[" << testLocal.x << "," << testLocal.y << "]" );

        // The robot is at 0,0 in the OccupancyGrid
        geometry_msgs::Point zero;
        zero.x=0;
        zero.y=0;

        //Basic Mode
        if(!advanceMode)
        {
          //Commence only if the robot 0 and 1 can be connected via a straight line, and when the laser onboard robot 0 can detect robot 1
          if(gridProcessing.checkConnectivity(zero,testLocal) && (LaserProcessing.detectPoseHighIntensity(testLocalPose)))
          {
            //Commence only if robot 0 and 1 are not next to each other
            if(sqrt(pow(abs(robot1pose.position.x-robot0pose.position.x),2)+pow(abs(robot1pose.position.y-robot0pose.position.y),2))>0.55)
            {
              if(goalBuffer==true)
              {
                // The target or goal pose is set as the leaders pose, which is latter fed into the path publisher
                goalPose=robot1pose;
                target_poses_.poses.push_back(goalPose);
                path_pub_.publish(target_poses_);
                //Setting the flags to false allows the robot to commence driving towards the goal pose
                goalBuffer=false;
                //Exporting the marker array and publishing the arrows
                visualization_msgs::MarkerArray goalMarker=exportMarker(goalPose,goalColor);
                viz2_pub_.publish(goalMarker);

              }

            }
            //The follower robot has reached its goal pose only if the distance between goal pose and its position is less than the specified threshold
            if(sqrt(pow(abs(goalPose.position.x-robot0pose.position.x),2)+pow(abs(goalPose.position.y-robot0pose.position.y),2))<=0.15)
            {
              //Setting the flag to true, allows for setting a new goal pose as per the code section above
              goalBuffer=true;
              //Exporting the marker array and publish the arrows
              visualization_msgs::MarkerArray goalMarker=exportMarker(goalPose,goalColor);
              viz2_pub_.publish(goalMarker);
              ROS_INFO_STREAM("Robot 0 has reached goal pose");
              //Clearing the pose array as per instructions provided
              target_poses_.poses.clear();
              path_pub_.publish(target_poses_);
            }
            if(sqrt(pow(abs(robot1pose.position.x-robot0pose.position.x),2)+pow(abs(robot1pose.position.y-robot0pose.position.y),2))<=0.55)
            {
               ROS_INFO_STREAM("Robot 0 has reached Robot 1");
            }
            else {
              ROS_INFO_STREAM("Robot 0 driving towards Robot 1");
              //Exporting the goal Pose and Interim pose markers arrays and publishing the arrows
              visualization_msgs::MarkerArray goalMarker=exportMarker(goalPose,goalColor);
              viz2_pub_.publish(goalMarker);
              visualization_msgs::MarkerArray interimMarker=exportMarker(robot0pose,interimColor);
              viz3_pub_.publish(interimMarker);
            }
          }
        }


        //Advanced Mode
        if(advanceMode)
        {
          //Commence only if the robot 0 and 1 can be connected via a straight line, and when the laser onboard robot 0 can detect robot 1
          if(gridProcessing.checkConnectivity(zero,testLocal) && (LaserProcessing.detectPoseHighIntensity(testLocalPose)))
          {
            //Commence only if robot 0 and 1 are not next to each other
            if(sqrt(pow(abs(robot1pose.position.x-robot0pose.position.x),2)+pow(abs(robot1pose.position.y-robot0pose.position.y),2))>0.8 && checkStationaryLeader==false)
            {
              if(goalBuffer==true)
              {
                // The target or goal pose is set as the leaders pose, which is latter fed into the path publisher
                goalPose=robot1pose;
                target_poses_.poses.push_back(goalPose);
                path_pub_.publish(target_poses_);
                //Setting the flags to false allows the robot to commence driving towards the goal pose
                goalBuffer=false;
                visualization_msgs::MarkerArray goalMarker=exportMarker(goalPose,goalColor);
                viz2_pub_.publish(goalMarker);
              }

            }
            //The follower robot has reached its goal pose only if the distance between goal pose and its position is less than the specified threshold
            if(sqrt(pow(abs(goalPose.position.x-robot0pose.position.x),2)+pow(abs(goalPose.position.y-robot0pose.position.y),2))<=0.25)
            {
              goalBuffer=true;
              visualization_msgs::MarkerArray goalMarker=exportMarker(goalPose,goalColor);
              viz2_pub_.publish(goalMarker);
              ROS_INFO_STREAM("Robot 0 has reached goal pose");
              target_poses_.poses.clear();
              path_pub_.publish(target_poses_);
            }
            if(sqrt(pow(abs(robot1pose.position.x-robot0pose.position.x),2)+pow(abs(robot1pose.position.y-robot0pose.position.y),2))<=0.55)
            {
               ROS_INFO_STREAM("Robot 0 has reached Robot 1");
            }
            else {
              ROS_INFO_STREAM("Robot 0 driving towards Robot 1");
              visualization_msgs::MarkerArray goalMarker=exportMarker(goalPose,goalColor);
              viz2_pub_.publish(goalMarker);
              visualization_msgs::MarkerArray interimMarker=exportMarker(robot0pose,interimColor);
              viz3_pub_.publish(interimMarker);
            }
          }
          //Commence the automatic following and parking directions only if the leader has been stationary
          if(checkStationaryLeader==true)
          {
            //If the leader has been stationary for a period of time between 1 and 10 seconds then move 0.5m behind it
            if(timePassedLeader>=1 && wayP_0==false && sqrt(pow(abs(goalPose.position.x-robot0pose.position.x),2)+pow(abs(goalPose.position.y-robot0pose.position.y),2))<=0.25)
            {

              ROS_INFO_STREAM("Aiming for 0.5 m behind leader");
              //target_poses_.poses.clear();
              double yaw=tf::getYaw(robot1pose.orientation);
              double theta=0;
              if(yaw<=0 && yaw<=M_PI)
              {
                theta=yaw+M_PI;
              }
              if(yaw>0 && yaw<180)
              {
                theta=yaw-M_PI;
              }
              wayPoint0.position.x=robot1pose.position.x+(0.5*cos(theta));
              wayPoint0.position.y=robot1pose.position.y+(0.5*sin(theta));
              wayPoint0.orientation=robot1pose.orientation;
              flagcheck=wayPoint0;
              target_poses0_.poses.push_back(wayPoint0);
              path_pub_.publish(target_poses0_);
              std::this_thread::sleep_for(std::chrono::milliseconds(1000));
              wayP_0=true;
            }
            //If the leader has been stationary for more than 10 seconds then commence the autonomous parking, robot 0 should park 0.5m on the right side of robot 1.
            if(timePassedLeader>10 && wayP_1==false && wayP_0==true && sqrt(pow(abs(flagcheck.position.x-robot0pose.position.x),2)+pow(abs(flagcheck.position.y-robot0pose.position.y),2))<=0.1)
            {

              ROS_INFO_STREAM("Autonomous Parking");
              //target_poses_.poses.clear();
              //New way point is extending to the right of the robot 1 by 0.5 m, a slight y offset has also been introduced in order to avoid collision with the leader robot
              wayPoint1.position.x=robot1pose.position.x+0.5;
              if(robot0pose.position.y>robot1pose.position.y)
              {
                wayPoint1.position.y=robot0pose.position.y+0.16;
              }
              if(robot0pose.position.y<robot1pose.position.y)
              {
                wayPoint1.position.y=robot0pose.position.y-0.16;
              }
              //wayPoint1.position.y=robot0pose.position.y;
              wayPoint1.orientation=robot1pose.orientation;
              target_poses2_.poses.push_back(wayPoint1);
              path_pub_.publish(target_poses2_);
              std::this_thread::sleep_for(std::chrono::milliseconds(1000));
              wayP_1=true;
            }
          }
          //Final waypoint for the autonomous parking
          if(checkStationaryLeader==true && wayP_1==true && (abs(robot0pose.position.x-wayPoint1.position.x))<0.1)
          {
            ROS_INFO_STREAM("WP2");
            target_poses2_.poses.clear();
            //Final Way point, robot 0 should be at the right side, 0.5 meters away from robot 1
            wayPoint2.position.x=wayPoint1.position.x;
            wayPoint2.position.y=robot1pose.position.y;
            wayPoint2.orientation=robot1pose.orientation;
            target_poses2_.poses.push_back(wayPoint2);
            path_pub_.publish(target_poses2_);
          }
        }

        rate_limiter.sleep();

    }
}

//Obstacle avoidance method, works but didnt have time to implement it at the specific section I wanted
void RosInteroperability::avoidObstacle()
{
  geometry_msgs::Twist vel_msg;
  vel_msg.linear.x=0.0;
  vel_msg.angular.z=0.5;
  std::vector<geometry_msgs::Twist> velo_array;
  velo_array.push_back(vel_msg);

  pub.publish(vel_msg);
}

//Velocity control method, works but didnt have time to implement it at the specific section I wanted
void RosInteroperability::moveRobot(geometry_msgs::PoseArray targetq_poses_, geometry_msgs::Pose pose)
{

  geometry_msgs::Twist vel_msg;
  geometry_msgs::Twist vel2_msg;
  // Reference :http://wiki.ros.org/turtlesim/Tutorials/Go%20to%20Goal
  std::vector<geometry_msgs::Twist> velo_array;


  geometry_msgs::Pose goalPose4;
  for (unsigned int i=0; i<targetq_poses_.poses.size(); i++)
  {
    double inc_x=targetq_poses_.poses.at(1).position.x-pose.position.x;
    double inc_y=targetq_poses_.poses.at(1).position.y-pose.position.y;
    double angle_to_goal=atan2(inc_y,inc_x);
    double distance=sqrt(pow(inc_x,2)+pow(inc_y,2));
    double para2=angle_to_goal-tf::getYaw(pose.orientation);

    double para3=abs(angle_to_goal-tf::getYaw(pose.orientation));
    double angle=angle_to_goal;
    ROS_INFO_STREAM("Para3 is: "<<para3);
    ROS_INFO_STREAM("Angle is: "<<angle);
    bool flag2;

          if(para2>0.087)
          {
               vel_msg.linear.x=0.0;
               vel_msg.angular.z=0.5;
               velo_array.push_back(vel_msg);

          }
          else if(para2<-0.087)
          {
            vel_msg.linear.x=0.0;
            vel_msg.angular.z=-0.5;
            velo_array.push_back(vel_msg);
          }
          else
          {
               vel_msg.linear.x=0.2;
               vel_msg.angular.z=0.0;
               velo_array.push_back(vel_msg);

           }
          //ROS_INFO_STREAM("Linear v is: "<<velocities_array.at(i).linear.x<<" ANgular velocity is: "<<velocities_array.at(i).angular.z);
         pub.publish(vel_msg);

  }

}


void RosInteroperability::filterVelocity(const geometry_msgs::Twist& msg)
{
  linX=msg.linear.x;
  angZ=msg.angular.z;
}

void RosInteroperability::filterVelocityLeader(const geometry_msgs::Twist& msg)
{
  linX1=msg.linear.x;
  angZ1=msg.angular.z;
}

bool RosInteroperability::CheckIfStationaryLeader()
{
  if(linX1==0 && angZ1==0)
  {
    //ROS_INFO_STREAM("Robot is stationary");
    return true;
  }
  else {
    //ROS_INFO_STREAM("Robot is not stationary");
    return false;
  }
}

bool RosInteroperability::CheckIfStationary()
{
  if(linX==0 && angZ==0)
  {
    //ROS_INFO_STREAM("Robot is stationary");
    return true;
  }
  else {
//    ROS_INFO_STREAM("Robot is not stationary");
    return false;
  }
}



void RosInteroperability::feedData()
{

  if (checkStationary==true)
  {
    timePassed=timePassed+1; //Update the timer by 1 second
  }
  if (checkStationary==false)
  {
    timePassed=0;  //Restart the timer
  }

}

void RosInteroperability::feedDataLeader()
{

  if (checkStationaryLeader==true)
  {
    timePassedLeader=timePassedLeader+1; //Update the timer by 1 second
  }
  if (checkStationaryLeader==false)
  {
    timePassedLeader=0;  //Restart the timer
  }

}


visualization_msgs::MarkerArray RosInteroperability::exportMarker(geometry_msgs::Pose robotPose,std_msgs::ColorRGBA color)
{

  visualization_msgs::MarkerArray markerArray;
  visualization_msgs::Marker marker;

  int marker_counter=0;
  //We need to set the frame
  // Set the frame ID and time stamp.
  marker.header.frame_id = "/world";
  //single_marker_person.header.stamp = ros::Time();
  marker.header.stamp = ros::Time::now();


  //We set lifetime (it will dissapear in this many seconds)
  marker.lifetime = ros::Duration(10);
  // Set the namespace and id for this marker.  This serves to create a unique ID
  // Any marker sent with the same namespace and id will overwrite the old one
  marker.ns = "test";
  marker.id = marker_counter++;

  // The marker type, we use a cylinder in this example
  marker.type = visualization_msgs::Marker::ARROW;

  // Set the marker action.  Options are ADD and DELETE (we ADD it to the screen)
  marker.action = visualization_msgs::Marker::ADD;

  //Introduced a slight offset cause it always seemed to render a bit to the right of the designated pose
  marker.pose.position.x = robotPose.position.x-0.128;
  marker.pose.position.y = robotPose.position.y;
  marker.pose.orientation=robotPose.orientation;



  // Set the scale of the marker -- 0.5x0.5x0.5 here means 0.5m side
  marker.scale.x = 0.5;
  marker.scale.y = 0.1;
  marker.scale.z = 0.1;


  //Colour is r,g,b, depending on the pose required
  marker.color = color;


  //We push the marker back on our array of markers
  markerArray.markers.push_back(marker);

  return markerArray;



}

