var searchData=
[
  ['newscan',['newScan',['../class_laser_processing.html#a4a2384c6a582a81333402ae5296382be',1,'LaserProcessing']]]
];
