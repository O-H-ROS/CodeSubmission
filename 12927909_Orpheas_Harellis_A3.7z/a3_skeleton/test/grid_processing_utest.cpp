/**
 * @brief Assignment 3 Unit Tets
 * @note  Project 4 Personal Assistant (Trajectory Following)
 * @note  The unit tests include:
 * @note  1. Line of Sight Test (Basic Mode)
 * @note  2. Sequence of Poses (Basic Mode)
 * @note  3. Moving behind the leader robot (Advanced Mode)
 * @author Orpheas Harellis 12927909
 * @date November 2021
 */

#include <gtest/gtest.h>
#include <climits>
#include <chrono>
#include <thread>
#include <iostream>
#include <time.h>


//This tool allows to identify the path of the package on your system
#include <ros/package.h>

//These allow us to inspect bags of data
#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <sensor_msgs/LaserScan.h>

//We include our header file
#include "../src/grid_processing.h"
#include "../src/laser_processing.h"
#include "../src/Ros_Interoperability.h"




//==================== HELPER FUNCTIONS ====================//
void printCells(nav_msgs::OccupancyGrid grid) {
  for (unsigned int row=0;row<grid.info.height-1;row++){
    for (unsigned int col=0;col<grid.info.width-1;col++){
      unsigned int index=(row*grid.info.height)+col;
      std::cout << static_cast<int>(grid.data.at(index)) << " ";
    }
    std::cout << std::endl;
  }

}
//==================== HELPER FUNCTIONS ====================//





TEST(LineofSight,BasicModeTest){

  //! The below code tests and examines whether robot 1 is visible or not from the follower robot 0
  //! An obstacle detection feature, in this case wall detection has also been established to check wheter the robot can distinguish between a wall and the following robot
  //! Three tests have been created:
  //! 1. Check whether robot 1 is within the occupancy grid of robot 0, via employing the GridProcessing::checkConnectivity method
  //! 2. Check wheter robot 1 is visible within the laser scan field of view of robot 0
  //! 3. Check wheter robot 0 has detected a wall.
  //! The simulation runs as the following: The leader is placed behind the follower.
  //! The data has been saved in a bag, that is opened and used.

  //! Below command allows to find the folder belonging to a package (a3_12927909 is the package name not the folder name)
  std::string path = ros::package::getPath("a3_12927909");

  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";

  //! The file is called LineofSight.bag
  std::string file = path + "LineofSight.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  // BagMode is Read by default

  nav_msgs::OccupancyGrid::ConstPtr grid;   //We need to have a pointer to extract the grid
  sensor_msgs::LaserScanConstPtr laserScan; //We need to have a pointer to extract the laser readings
  nav_msgs::OdometryConstPtr robot_1;       //We need to have a pointer to extract the odom messages for the poses
  nav_msgs::OdometryConstPtr robot_0;       //We need to have a pointer to extract the odom messages for the poses

  //Obtaining the grid
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/local_map/local_map"){ //Commented out so as to obtain the data throught the bag life, instead of just the first instance we receive data from the subscribed topic
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    //}
    if (grid != nullptr){
      // Now we have the first grid in bag so we can proceed
      break;
    }
  }

  //Obtaining the odometry for robot 1 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_1/odom"){
      robot_1 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_1 != nullptr){
      break;
    }
  }

  //Obtaining the odometry for robot 0 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_0 != nullptr){
      break;
    }
  }

  //Obtaining the laser scan for the follower robot 0
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_0/base_scan"){
      laserScan = m.instantiate<sensor_msgs::LaserScan>();
    //}
    if (laserScan != nullptr){
      break;
    }
  }

  bag.close();

  ASSERT_NE(grid, nullptr);//Check that we have a grid from the bag
  ASSERT_NE(robot_1, nullptr);//Check that we have odometry 1 from the bag
  ASSERT_NE(robot_0, nullptr);//Check that we have odometry 0 from the bag
  ASSERT_NE(laserScan, nullptr);//Check that we have a laser scan from the bag

  GridProcessing gridProcessing(*grid);
  LaserProcessing laserProcessing(*laserScan,robot_0->pose.pose);

  geometry_msgs::Pose robot0pose, robot1pose;
  robot1pose=robot_1->pose.pose;
  robot0pose= robot_0->pose.pose;

  double yaw_robot_0, yaw_robot_1;
  yaw_robot_1=tf::getYaw(robot1pose.orientation);
  yaw_robot_0=tf::getYaw(robot0pose.orientation);

  //Converting into robot centric coordinates and storing them in a pose
  geometry_msgs::Point testLocal;
  testLocal.x = robot1pose.position.x - robot0pose.position.x; //Global to robotic local
  testLocal.y = robot1pose.position.y - robot0pose.position.y;

  geometry_msgs::Pose testLocalPose;
  testLocalPose.position.x=testLocal.x;
  testLocalPose.position.y=testLocal.y;
  testLocalPose.position.z=0;

  // The robot is at 0,0 in the OccupancyGrid
  geometry_msgs::Point zero;
  zero.x=0;
  zero.y=0;

  //Robot 1 is within the occupancy grid of robot 0, therefore the below function should return true
  EXPECT_TRUE(gridProcessing.checkConnectivity(zero,testLocal));

  //Robot 1 is exactly behind robot 0 facing it, therefore it is outside of the field of view of robot 0 and the following function shoudl return false
  EXPECT_FALSE(laserProcessing.detectPoseHighIntensity(testLocalPose));


}

TEST(SequentialPoses,BasicModeTest){

  //! The below code tests and examines a sequence of computed poses, in order to maintain line of sight when following the robot
  //! Exploiting ros bags is not thread safe, I tried manipulating timers and the view.addQuery method to extract topics at specifics timelines however, I was unsuccessful
  //! As a result, this unit test consists of 3 bags, that are tested individually in a sequence, for each next bag created the previous conditions have been simulated to ensure a sequence of computed poses.
  //! The first bag checks whether robot 1 can be connected by a straight line with robot 0, no obstacles in between
  //! The second bag assess whether robot 0 has hit the required goal pose near the wall corner, while the leader is still moving away from that goal pose
  //! While the third bag, assesses whether the robot 0 is capable of tracking the leader robot past the corner
  //! A small schematic can be previewed below
  //! The data has been saved in bags, that are opened and used.

  // Simulation and path planning of first bag, both robots are stationary
  //
  //    Bag #1
  //                     ↗
  //             (R 1)  o ____________
  //                    |
  //            ↗       | (Corner)
  //           o (R 0)  |
  //                    |
  //

  // Simulation and path planning of second bag, follower robot (R 0) reaches the goal pose of the leader robot (R 1)
  //
  //     Bag #1               (R 1)
  //                     ↗    o ->
  //             (R 0)  o ___________
  //                    |
  //                    | (Corner)
  //                    |
  //                    |
  //

  // Simulation and path planning of third bag, follower robot (R 0) reaches the goal pose of the leader robot (R 1) after passing the corner
  //
  //    Bag #3               (R 0)   (R 1)
  //                         o ->     o->
  //                      __________________
  //                    |
  //                    | (Corner)
  //                    |
  //                    |
  //


  //! Below command allows to find the folder belonging to a package (a3_12927909 is the package name not the folder name)
  std::string path = ros::package::getPath("a3_12927909");

  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";

  //! The file is called SequentialPosesBag1.bag
  std::string file = path + "SequentialPosesBag1.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  // BagMode is Read by default

  nav_msgs::OccupancyGrid::ConstPtr grid;   //We need to have a pointer to extract the grid
  sensor_msgs::LaserScanConstPtr laserScan; //We need to have a pointer to extract the laser readings
  nav_msgs::OdometryConstPtr robot_1;       //We need to have a pointer to extract the odom messages for the poses
  nav_msgs::OdometryConstPtr robot_0;       //We need to have a pointer to extract the odom messages for the poses

  //Obtaining the grid
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/local_map/local_map"){ //Commented out so as to obtain the data throughout the bag life, instead of just the first instance we receive data from the subscribed topic
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    //}
    if (grid != nullptr){
      // Now we have the first grid in bag so we can proceed
      break;
    }
  }

  //Obtaining the odometry for robot 1 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_1/odom"){
      robot_1 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_1 != nullptr){
      break;
    }
  }

  //Obtaining the odometry for robot 0 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_0 != nullptr){
      break;
    }
  }

  //Obtaining the laser scan for the follower robot 0
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_0/base_scan"){
      laserScan = m.instantiate<sensor_msgs::LaserScan>();
    //}
    if (laserScan != nullptr){
      break;
    }
  }

  bag.close();

  ASSERT_NE(grid, nullptr);//Check that we have a grid from the bag
  ASSERT_NE(robot_1, nullptr);//Check that we have odometry 1 from the bag
  ASSERT_NE(robot_0, nullptr);//Check that we have odometry 0 from the bag
  ASSERT_NE(laserScan, nullptr);//Check that we have a laser scan from the bag

  GridProcessing gridProcessing(*grid);
  LaserProcessing laserProcessing(*laserScan,robot_0->pose.pose);

  geometry_msgs::Pose robot0pose, robot1pose;
  robot1pose=robot_1->pose.pose;
  robot0pose= robot_0->pose.pose;

  double yaw_robot_0, yaw_robot_1;
  yaw_robot_1=tf::getYaw(robot1pose.orientation);
  yaw_robot_0=tf::getYaw(robot0pose.orientation);

  //Converting into robot centric coordinates and storing them in a pose
  geometry_msgs::Point testLocal;
  testLocal.x = robot1pose.position.x - robot0pose.position.x; //Global to robotic local
  testLocal.y = robot1pose.position.y - robot0pose.position.y;

  geometry_msgs::Pose testLocalPose;
  testLocalPose.position.x=testLocal.x;
  testLocalPose.position.y=testLocal.y;
  testLocalPose.position.z=0;

  // The robot is at 0,0 in the OccupancyGrid
  geometry_msgs::Point zero;
  zero.x=0;
  zero.y=0;

  //Robot 1 is within the occupancy grid of robot 0, therefore the below function should return true
  EXPECT_TRUE(gridProcessing.checkConnectivity(zero,testLocal));


  //Bag 2 test
  //! The file is called SequentialPosesBag2.bag
  file = path + "SequentialPosesBag2.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag2;
  bag2.open(file);  // BagMode is Read by default

  nav_msgs::OccupancyGrid::ConstPtr grid_b2;   //We need to have a pointer to extract the grid
  sensor_msgs::LaserScanConstPtr laserScan_b2; //We need to have a pointer to extract the laser readings
  nav_msgs::OdometryConstPtr robot_1_b2;       //We need to have a pointer to extract the odom messages for the poses
  nav_msgs::OdometryConstPtr robot_0_b2;       //We need to have a pointer to extract the odom messages for the poses

  //Obtaining the grid
  for(rosbag::MessageInstance const m: rosbag::View(bag2))
  {
    //if(m.getTopic() == "/local_map/local_map"){ //Commented out so as to obtain the data throughout the bag life, instead of just the first instance we receive data from the subscribed topic
      grid_b2 = m.instantiate<nav_msgs::OccupancyGrid>();
    //}
    if (grid_b2 != nullptr){
      // Now we have the first grid in bag so we can proceed
      break;
    }
  }

  //Obtaining the odometry for robot 1 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag2))
  {
    if(m.getTopic() == "/robot_1/odom"){                        //By uncommenting this line, it allows us to store the first reading of the pose of the leader robot as soon as the topic has been received,
      robot_1_b2 = m.instantiate<nav_msgs::Odometry>();         //This enables to us to consider this pose as the goal pose
    }
    if (robot_1_b2 != nullptr){
      break;
    }
  }

  //Obtaining the odometry for robot 0 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag2))
  {
    //if(m.getTopic() == "/robot_0/odom"){
      robot_0_b2 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_0_b2 != nullptr){
      break;
    }
  }

  //Obtaining the laser scan for the follower robot 0
  for(rosbag::MessageInstance const m: rosbag::View(bag2))
  {
    //if(m.getTopic() == "/robot_0/base_scan"){
      laserScan_b2 = m.instantiate<sensor_msgs::LaserScan>();
    //}
    if (laserScan_b2 != nullptr){
      break;
    }
  }

  bag2.close();

  geometry_msgs::Pose robot_0_pose_2, robot_1_pose_2;

  //Robot 1 (leader robot) pose has been registered as the pose only just before it started moving therefore it represents the goal pose (see line number 493 for more info)
  robot_1_pose_2=robot_1_b2->pose.pose;
  robot_0_pose_2=robot_0_b2->pose.pose;

  geometry_msgs::Point testLocal2;
  testLocal2.x = robot_1_pose_2.position.x - robot_0_pose_2.position.x; //Global to robotic local
  testLocal2.y = robot_1_pose_2.position.y - robot_0_pose_2.position.y;


  //Robot 1 is still within the occupancy grid of robot 0 with no obstacles in between, therefore the below function should return true
  EXPECT_TRUE(gridProcessing.checkConnectivity(zero,testLocal2));


  //The follower robot 0 has reached the goal pose
  EXPECT_NEAR(robot_0_pose_2.position.x,robot_1_pose_2.position.x,0.2);
  EXPECT_NEAR(robot_0_pose_2.position.y,robot_1_pose_2.position.y,0.2);


  //Bag 3 test
  //! The file is called SequentialPosesBag3.bag
  file = path + "SequentialPosesBag3.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag3;
  bag3.open(file);  // BagMode is Read by default

  nav_msgs::OccupancyGrid::ConstPtr grid_b3;   //We need to have a pointer to extract the grid
  sensor_msgs::LaserScanConstPtr laserScan_b3; //We need to have a pointer to extract the laser readings
  nav_msgs::OdometryConstPtr robot_1_b3;       //We need to have a pointer to extract the odom messages for the poses
  nav_msgs::OdometryConstPtr robot_0_b3;       //We need to have a pointer to extract the odom messages for the poses

  //Obtaining the grid
  for(rosbag::MessageInstance const m: rosbag::View(bag3))
  {
    //if(m.getTopic() == "/local_map/local_map"){ //Commented out so as to obtain the data throughout the bag life, instead of just the first instance we receive data from the subscribed topic
      grid_b3 = m.instantiate<nav_msgs::OccupancyGrid>();
    //}
    if (grid_b3 != nullptr){
      // Now we have the first grid in bag so we can proceed
      break;
    }
  }

  //Obtaining the odometry for robot 1 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag3))
  {
    //if(m.getTopic() == "/robot_1/odom"){
      robot_1_b3 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_1_b3 != nullptr){
      break;
    }
  }

  //Obtaining the odometry for robot 0 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag3))
  {
    //if(m.getTopic() == "/robot_0/odom"){
      robot_0_b3 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_0_b3 != nullptr){
      break;
    }
  }

  //Obtaining the laser scan for the follower robot 0
  for(rosbag::MessageInstance const m: rosbag::View(bag3))
  {
    //if(m.getTopic() == "/robot_0/base_scan"){
      laserScan_b3 = m.instantiate<sensor_msgs::LaserScan>();
    //}
    if (laserScan_b3 != nullptr){
      break;
    }
  }

  bag3.close();

  geometry_msgs::Pose robot_0_pose_3, robot_1_pose_3;


  robot_1_pose_3=robot_1_b3->pose.pose;
  robot_0_pose_3=robot_0_b3->pose.pose;


  //From the simulation inside the ros bag robot 0 (follower) should be very close to where robot 1 (leader) used to be, we justifies the increase in the expect near range threshold by a bit
  //The following robot has reached the goal pose
  EXPECT_NEAR(robot_0_pose_3.position.x,robot_1_pose_3.position.x,0.25);
  EXPECT_NEAR(robot_0_pose_3.position.y,robot_1_pose_3.position.y,0.25);




  geometry_msgs::Point testLocal3;
  testLocal3.x = robot_1_pose_3.position.x - robot_0_pose_3.position.x; //Global to robotic local
  testLocal3.y = robot_1_pose_3.position.y - robot_0_pose_3.position.y;


  //Robot 1 is still within the occupancy grid of robot 0 with no obstacles in between, therefore the below function should return true
  EXPECT_TRUE(gridProcessing.checkConnectivity(zero,testLocal3));



}



TEST(Localisation,AdvancedModeTest){

  //! The below code tests and examines whether the pose of the follower is 0.5m behind the leader robot and facing it
  //! The data has been saved in a bag, that is opened and used.

  //! Below command allows to find the folder belonging to a package (a3_12927909 is the package name not the folder name)
  std::string path = ros::package::getPath("a3_12927909");

  //! Now we have the path, the images for our testing are stored in a subfolder /test/samples
  path += "/test/samples/";

  //! The file is called AdvancedMode.bag
  std::string file = path + "BagTest1.bag";

  //! Manipulating rosbag, from: http://wiki.ros.org/rosbag/Code%20API
  rosbag::Bag bag;
  bag.open(file);  // BagMode is Read by default

  nav_msgs::OccupancyGrid::ConstPtr grid;   //We need to have a pointer to extract the grid
  sensor_msgs::LaserScanConstPtr laserScan; //We need to have a pointer to extract the laser readings
  nav_msgs::OdometryConstPtr robot_1;       //We need to have a pointer to extract the odom messages for the poses
  nav_msgs::OdometryConstPtr robot_0;       //We need to have a pointer to extract the odom messages for the poses

//  rosbag::View view(bag);
//  ros::Time bag_begin_time=view.getBeginTime();
//  ros::Time bag_end_time=view.getEndTime();
//  std::cout<<"Ros bag time :"<<(bag_end_time-bag_begin_time).toNSec()<<std::endl;

  //Obtaining the grid
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/local_map/local_map"){ //Commented out so as to obtain the data throught the bag life, instead of just the first instance we receive data from the subscribed topic
      grid = m.instantiate<nav_msgs::OccupancyGrid>();
    //}
    if (grid != nullptr){
      // Now we have the first grid in bag so we can proceed
      break;
    }
  }

  //Obtaining the odometry for robot 1 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_1/odom"){
      robot_1 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_1 != nullptr){
      break;
    }
  }

  //Obtaining the odometry for robot 0 from the bag
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_0/odom"){
      robot_0 = m.instantiate<nav_msgs::Odometry>();
    //}
    if (robot_0 != nullptr){
      break;
    }
  }

  //Obtaining the laser scan for the follower robot 0
  for(rosbag::MessageInstance const m: rosbag::View(bag))
  {
    //if(m.getTopic() == "/robot_0/base_scan"){
      laserScan = m.instantiate<sensor_msgs::LaserScan>();
    //}
    if (laserScan != nullptr){
      break;
    }
  }

  bag.close();

  ASSERT_NE(grid, nullptr);//Check that we have a grid from the bag
  ASSERT_NE(robot_1, nullptr);//Check that we have odometry 1 from the bag
  ASSERT_NE(robot_0, nullptr);//Check that we have odometry 0 from the bag
  ASSERT_NE(laserScan, nullptr);//Check that we have a laser scan from the bag

  GridProcessing gridProcessing(*grid);
  LaserProcessing laserProcessing(*laserScan,robot_0->pose.pose);

  geometry_msgs::Pose robot0pose, robot1pose;
  robot1pose=robot_1->pose.pose;
  robot0pose= robot_0->pose.pose;

  double yaw_robot_0, yaw_robot_1;
  yaw_robot_1=tf::getYaw(robot1pose.orientation);
  yaw_robot_0=tf::getYaw(robot0pose.orientation);

  //Calculating the goal pose to be 0.5m behind the parker leader robot 1
  geometry_msgs::Pose goalPose;
  goalPose.position.x=robot1pose.position.x;
  goalPose.position.y=robot1pose.position.y-0.5;
  goalPose.position.z=0;

  //The following robot should be behind the leader by 0.5m with very similar orientation
  EXPECT_NEAR(robot0pose.position.x,goalPose.position.x,0);
  EXPECT_NEAR(robot0pose.position.y,goalPose.position.y,0.5);
  EXPECT_NEAR(yaw_robot_0,yaw_robot_1,8);

}



int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
