/*! @file BasicPathPlanning.h
 *
 *  @brief Basic Game Mode Class
 *
 *  This header and its structures are used to assist in the estimation of bogie positions and related data
 *  that will allow for the aircraft to accurately intercept the stationary bogies efficiently.
 *
 *  @author Orpheas K. Harellis
 *  @date 13-10-2021
*/

#ifndef BASICPATHPLANNING_H
#define BASICPATHPLANNING_H


#include "aircraft.h"
#include "timer.h"
#include "simulator.h"
#include "tf.h"

#include <vector>
#include <cmath>
#include <condition_variable>

using namespace simulator;
using namespace geometry_msgs;

/**
* @brief Collection of simple data containers
*
*/
namespace Containers {

    struct OnBoardRadar{                                /*!< A thread safe container for the timestamped range/bearing reading type */

        std::vector<RangeBearingStamped> RnBnS_vector_;
        std::mutex mtx;
        std::condition_variable cv;

        };

    struct Bogie{                                       /*!< Vector that contains a timestamped range/bearing reading */

        Pose bogie_pose_;                               /*!< Position and orientation of the bogie within the airspace */
        double range;                                   /*!< Range in (metres/second) */
        Pose f_pose_;                                   /*!< Current global goal position and orientation within the airspace. */
        long double timestamp_;                         /*!< Timestamp (milliseconds) */
    };

    struct BogieContainer{                              /*!< A thread safe container for the Bogie type */

        std::vector<Bogie> bogie_vector_;
        std::mutex mtx;
        std::condition_variable cv;
    };

    struct TimerContainer{                              /*!< A thread safe container for the range/bearing reading and for time to intercept */

        std::vector<RangeBearingStamped> bogie_vector_;
        std::vector<double> timetointerept_vector;

    };

    struct Friendly_air{                                /*!< A thread safe container for the friendly aircraft */
        Pose friendly_pose_;                            /*!< Global position and orientation within the airspace */
        std::mutex mtx;
        std::condition_variable cv;

    };
}

class BasicRadar
{

public:

    /**
    * @brief Default constructor
    *
    */
    BasicRadar();

    /**
    * @brief Default destructor
    *
    */
    ~BasicRadar();

    /**
    * @brief Calculation of a target's location
    * @param Pose friendly aircraft, vector of RangeBearingStamped of bogies
    */
    void locateTargets(Pose, std::vector<RangeBearingStamped>);


    /**
     * @brief Compute x,y location of bogie in the reference frame of base station (which is at 0,0)
     * @param rangeBearing - (polar coordinates) of bogie, obtained from the Pose suppplied
     * @param aircraft - Pose where the readings were obtained, this pose in relative to map origin (base station)
     * @return location of bogie relative to map origin (base station)
     */
    Point local2Global(RangeBearingStamped rangeBearing, Pose aircraft);

    /**
     * @brief compute the range and bearig (polar coordinates) of bogie) relative to aicrraft pose suppplied
     * @param globalBogie - x,y location of bogie in the reference frame of (base station)
     * @param aircraft - Pose relative to map origin (base station)
     * @return rangeBearing - (polar coordinates of bogie) relative to the aircraft Pose suppplied
     */
    RangeBearingStamped global2local(Point globalBogie, Pose aircraft);

    /**
     * @brief Compute x,y location of bogie in the reference frame of base station (which is at 0,0)
     * @param vector of rangeBearing - (polar coordinates) of bogie, obtained from the Pose suppplied
     * @param aircraft - Pose where the readings were obtained, this pose in relative to map origin (base station)
     * @return vector of location of bogies relative to map origin (base station)
     */
    std::vector<Point> PointInGlobal(std::vector<RangeBearingStamped> rbvec, Pose air_pose);

    /**
     * @brief
     * Normalises angle between 0 - 2PI, can only handle angles between -2PI to 4PI
     * @param angle
     * @return normalised angle
     */
    double normaliseAngle(double theta);


    /**
    * @brief Obtains the rangebearing data and bubblesorts them in ascending order based on the range in case the hypothesis of the assignment guidelines hasnt been met
    * @param vector of stamped range bearing data.
    */
    void setBogies(std::vector<RangeBearingStamped> &data);

    /**
    * @brief Obtains the rangebearing data and bubblesorts them in ascending order based on the time to intercept
    * @param vector of stamped range bearing data.
    */
    void setBogiesbyTime(Containers::TimerContainer &data);

    /**
    * @brief Getter function for the bogies
    * @return vector of range/bearing sorted in ascending order
    */
    std::vector<RangeBearingStamped> getBogies();


    /**
     * @brief Computes and returns the bogie poses for the sim->testPose for the basic mode
     * @param vector of Points - x and y coordinates of bogie
     * @param In this case position.z and orientation of bogies have been set to 0
     * @return vector of bogies poses that will be fed into the sim->testPose
     */
    std::vector<Pose> getBogiePoses(std::vector<Point> Points);

    /**
    * @brief Getter function for the location of the bogies in global frame
    * @return vector of pairs (x,y)
    */
    std::vector<std::pair<double,double>> getTargetOfInterest();

    /**
     * @brief Computes and returns the bogie poses for the sim->testPose for the basic mode
     * @param vector of Points - x and y coordinates of bogie
     * @param In this case position.z and orientation of bogies have been set to 0
     * @return vector of bogies poses that will be fed into the sim->testPose
     */
    std::vector<RangeBearingStamped> getTimedBogies();



private:
    std::vector<std::pair<double,double>> friendly2Base_;            /*!< Vector of pairs (x,y) for the location of friendly aircraft relative to the base */
    std::vector<std::pair<double,double>> friendly_radar_;           /*!< Vector of pairs (range,bearing) of the bogies */
    std::vector<std::pair<double,double>> friendly_Timedradar_;      /*!< Vector of pairs (range,bearing) of the bogies sorted in ascending order based on the time to intercept with friendly*/
    std::vector<RangeBearingStamped> friendly_radar_data;            /*!< Vector range/bearing to be passed on the object of BasicRadar, used in threading*/
    std::vector<RangeBearingStamped> friendly_radar_Timeddata;       /*!< Vector range/bearing to be passed on the object of BasicRadar, used in threading*/
    double targetAngle;                                              /*!< Placeholder for the bearing of the bogie */
    std::vector<std::pair<double,double>> targetsOfInterest_;        /*!< Vector of pairs (x,y) for the location of bogie relative to the base */
    std::vector<Pose>  bg_pose;                                      /*!< Vector of bogie poses to be used in sim->testPose */


};

#endif //BASICPATHPLANNING_H
