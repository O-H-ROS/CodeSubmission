#include "Threading.h"
#include "tf.h"
#include "types.h"
#include <climits>
#include <condition_variable>
#include <mutex>
#include "BasicPathPlanning.h"
#include "AdvancedPathPlanning.h"
#include "timer.h"
#include <chrono>

Threading::Threading(){

}

Threading::~Threading()
{

}



void Threading::ctrl(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar, Threading &data)
{
    while (true)
    {
        friendly_radar2_.RnBnS_vector_=sim->rangeBearingToBogiesFromFriendly();
        friendly_air.friendly_pose_=sim->getFriendlyPose();
        stationary_bogies=sim->rangeBearingToBogiesFromFriendly();
        std::vector<Point> stationaryBogies=Radar.PointInGlobal(stationary_bogies, friendly_air.friendly_pose_);
        //Locking the thread to locate stationary bogies, obtain bogie poses and update the testPose
        std::unique_lock<std::mutex> air_lck(friendly_radar2_.mtx);
        Radar.setBogies(friendly_radar2_.RnBnS_vector_);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        std::vector<Pose> currentPose_;
        std::vector<Pose> currentPose2_;
        currentPose_=Radar.getBogiePoses(stationaryBogies);
        for(unsigned int i=0; i<stationary_bogies.size(); i++)
        {
            currentPose2_.push_back(currentPose_.at(i));
        }
        sim->testPose(currentPose2_);
        Radar.locateTargets(friendly_air.friendly_pose_,friendly_radar2_.RnBnS_vector_);
        checkReady=true;
        friendly_radar2_.mtx.unlock();
        cv_.notify_all();
    }
}



void Threading::Advancedctrl(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar,AdvancedRadar &AdvRadar, Threading &data, Timer &tim)
{


    while (true)
    {
        updatedGoals.resize(4);
       f_pose_vector.clear();
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        // Obtaining data both for the friendly aircraft and the bogies
        friendly_radar2_.RnBnS_vector_=sim->rangeBearingToBogiesFromFriendly();
        simPose=sim->getFriendlyPose();
        //Locking the thread to locate moving bogies, obtain bogie poses and update the testPose
        std::unique_lock<std::mutex> lck(mu_);
        AdvRadar.setAdvancedBogies(friendly_radar2_.RnBnS_vector_);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        long time=10;
        // Locating moving targets
        AdvRadar.locateAdvancedTargets(simPose,friendly_radar2_.RnBnS_vector_, time);
        std::vector<Pose> futurePose_;
        std::vector<Pose> PosE2_;
        PosE2_=AdvRadar.getFuture();
        for(unsigned int k=0; k<friendly_radar2_.RnBnS_vector_.size(); k++)
        {
            f_pose_vector.push_back(PosE2_.at(k));
        }
        std::vector<Point> goals=AdvRadar.getGoals();
        for(unsigned int i=0; i<goals.size(); i++)
        {
            updatedGoals.at(i)=Radar.global2local(goals.at(i), simPose);
        }
        sim->testPose(f_pose_vector);
        checkReady=true;
        mu_.unlock();
        cv_.notify_all();
    }
}



void Threading::prcs(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, Pose air_pose)
{
    // Including a delay to allow for the watchdog timer to be met
    std::this_thread::sleep_for(std::chrono::milliseconds(25));
    //Locking the aircraft to allow for its position to change based on current detected target
    std::unique_lock<std::mutex> air_lck(friendly_air.mtx);
    while(true)
    {
        Pose posel;
        friendly_air.friendly_pose_=sim->getFriendlyPose();
        f_c.AircraftInitialisation(friendly_air.friendly_pose_);
        f_c.PurePursuit(closest_bogie,air_pose);
        double l_v=f_c.getLinear_V();
        double a_v=f_c.getAngular_V();
        sim->controlFriendly(l_v,a_v);
        friendly_air.mtx.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }
}



void Threading::DAQ_TH(const std::shared_ptr<Simulator> &sim, BasicRadar &Radar)
{
    while (true)
    {
        // Obtaining and updating the data for the bogie of interest that will later be fed into the pure pursuit controller
        std::unique_lock<std::mutex> lck(mu_);
        cv_.wait(lck, [&] { return (checkReady); });
        new_targets2.RnBnS_vector_=Radar.getBogies();
//        for (size_t i = 0; i < new_targets2.RnBnS_vector_.size() - 1; ++i) {
//                for (size_t j = 0; j < new_targets2.RnBnS_vector_.size() - i - 1; ++j) {
//                    if (new_targets2.RnBnS_vector_.at(j).range > new_targets2.RnBnS_vector_.at(j + 1).range)
//                        std::swap(new_targets2.RnBnS_vector_.at(j), new_targets2.RnBnS_vector_.at(j + 1));
//                }
//            }
        closest_bogie=new_targets2.RnBnS_vector_.at(0);
        new_targets2.RnBnS_vector_.clear();
        mu_.unlock();
        checkReady=false;
    }
}


void Threading::AdvancedDAQ_TH(const std::shared_ptr<Simulator> &sim, BasicRadar &Radar)
{
    while (true)
    {
        // Obtaining and updating the data for the bogie of interest that will later be fed into the pure pursuit controller
        std::unique_lock<std::mutex> lck(mu_);
        cv_.wait(lck, [&] { return (checkReady); });
        new_targets2.RnBnS_vector_=updatedGoals;

        closest_bogie=new_targets2.RnBnS_vector_.at(0);
        new_targets2.RnBnS_vector_.clear();
        mu_.unlock();
        checkReady=false;
    }
}


