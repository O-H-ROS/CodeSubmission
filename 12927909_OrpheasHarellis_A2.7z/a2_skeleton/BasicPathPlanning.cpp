
#include "BasicPathPlanning.h"
#include "types.h"
#include "BasicPathPlanningcopy.h"




BasicRadar::BasicRadar()
{

}

BasicRadar::~BasicRadar()
{

}


void BasicRadar::locateTargets(Pose sim_pose, std::vector<RangeBearingStamped> air_scan)
{
    Pose pose=sim_pose;
    double friendly_orientation=tf::quaternionToYaw(pose.orientation);
    double x=pose.position.x;
    double y=pose.position.y;
    std::vector<RangeBearingStamped> bogies=air_scan;
    for (size_t i = 0; i < bogies.size() - 1; ++i) {
            for (size_t j = 0; j < bogies.size() - i - 1; ++j) {
                if (bogies.at(j).range > bogies.at(j + 1).range)
                    std::swap(bogies.at(j), bogies.at(j + 1));
            }
        }
    auto closestBogie2Friendly=bogies.at(0);
    double range=closestBogie2Friendly.range;
    targetAngle=closestBogie2Friendly.bearing;
    double angle_=targetAngle+friendly_orientation;
    double x2=x+range*cos(angle_);
    double y2=y+range*sin(angle_);
    targetsOfInterest_.push_back(std::make_pair(x2,y2));
    bogies.clear();
}

RangeBearingStamped BasicRadar::global2local(Point bogie, Pose aircraft)
{
    RangeBearingStamped rbstamped = {0, 0,0};
    rbstamped.range=sqrt(pow(bogie.x-aircraft.position.x,2)+pow(bogie.y-aircraft.position.y,2));
    double f1=bogie.x;
    double f2=aircraft.position.x;
    double l1=bogie.y;
    double l2=aircraft.position.y;

    double phi=atan2(l1-l2,f1-f2); //In radians
    double epsilon=tf::quaternionToYaw(aircraft.orientation);
    double theta=2*M_PI-(epsilon-phi);
    rbstamped.bearing=normaliseAngle(theta);
    //std::cout<<"Bearing2 is: "<<rbstamped.bearing<<std::endl;
    //std::cout<<"Range2 is: "<<rbstamped.range<<std::endl;
    return rbstamped;
}


std::vector<std::pair<double,double>> BasicRadar::getTargetOfInterest()
{
    return targetsOfInterest_;
}

void BasicRadar::setBogies(std::vector<RangeBearingStamped> &data)
{
    std::vector<RangeBearingStamped> friendly_radar=data;
    for (size_t i = 0; i < friendly_radar.size() - 1; ++i) {
            for (size_t j = 0; j < friendly_radar.size() - i - 1; ++j) {
                if (friendly_radar.at(j).range > friendly_radar.at(j + 1).range)
                    std::swap(friendly_radar.at(j), friendly_radar.at(j + 1));
            }
        }
    friendly_radar_data=friendly_radar;
    for (unsigned int i=0; i<friendly_radar.size(); i++)
    {
        friendly_radar_.push_back(std::make_pair(friendly_radar.at(i).range,friendly_radar.at(i).bearing));
    }
}

void BasicRadar::setBogiesbyTime(Containers::TimerContainer &data)
{
    std::vector<RangeBearingStamped> friendly_radar=data.bogie_vector_;

    for (size_t i = 0; i < friendly_radar.size() - 1; ++i) {
            for (size_t j = 0; j < friendly_radar.size() - i - 1; ++j) {
                if (friendly_radar.at(j).timestamp > friendly_radar.at(j + 1).timestamp)
                    std::swap(friendly_radar.at(j), friendly_radar.at(j + 1));
            }
        }
    friendly_radar_Timeddata=friendly_radar;
    for (unsigned int i=0; i<friendly_radar.size(); i++)
    {
        friendly_Timedradar_.push_back(std::make_pair(friendly_radar.at(i).range,friendly_radar.at(i).bearing));
    }

}

std::vector<RangeBearingStamped> BasicRadar::getTimedBogies()
{
    return friendly_radar_Timeddata;
}

std::vector<RangeBearingStamped> BasicRadar::getBogies()
{
    return friendly_radar_data;
}

Point BasicRadar::local2Global(RangeBearingStamped rangeBearing, Pose aircraft)
{
    Point p;
    double bogie_bearing=fmod((rangeBearing.bearing+tf::quaternionToYaw(aircraft.orientation)),(2*M_PI));
    double b_x=(rangeBearing.range*cos(bogie_bearing))+aircraft.position.x;
    double b_y=(rangeBearing.range*sin(bogie_bearing))+aircraft.position.y;
    p.x=b_x;
    p.y=b_y;
    return p;

}

double BasicRadar::normaliseAngle(double theta) {
  if (theta > (2 * M_PI))
    theta = theta - (2 * M_PI);
  else if (theta < 0)
    theta = theta + (2 * M_PI);

  return theta;
}


std::vector<Point> BasicRadar::PointInGlobal(std::vector<RangeBearingStamped> rbvec, Pose air_pose)
{
    std::vector<Point> TotalPoints;
    for (unsigned int i=0; i<rbvec.size(); i++)
    {
        Point P_In_G=local2Global(rbvec.at(i), air_pose);
        TotalPoints.push_back(P_In_G);
    }
    return TotalPoints;
}



std::vector<Pose> BasicRadar::getBogiePoses(std::vector<Point> Points)
{
    std::vector<Pose> bg_pose;
    for(unsigned int i=0; i<Points.size(); i++)
    {
        Pose pose2;
        pose2.position.x=Points.at(i).x;
        pose2.position.y=Points.at(i).y;
        pose2.position.z=0;
        pose2.orientation=tf::yawToQuaternion(0);
        bg_pose.push_back(pose2);
    }
    return bg_pose;
}



