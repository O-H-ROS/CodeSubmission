#include "BasicPathPlanningcopy.h"
#include "tf.h"
#include "types.h"
#include <climits>
#include <math.h>
#include <cmath>
#include "simulator.h"


using namespace std;
using std::vector;
using std::pair;
using geometry_msgs::Point;

static const double GMAX=6*9.81;
static const double OMEGA_MAX=(GMAX)/(Simulator::V_TERM);
static const double OMEGA_MIN=(GMAX)/(Simulator::V_MAX);
static const double Aircraft_Size=200;
static const double MapMinX=(-(Simulator::AIRSPACE_SIZE/2) + Aircraft_Size); //Offsetting the aircraft's size to prevent the aircraft from "colliding" with the external boundaries
static const double MapMaxX=((Simulator::AIRSPACE_SIZE/2 - Aircraft_Size));
static const double MapMaxY=((Simulator::AIRSPACE_SIZE/2 - Aircraft_Size));
static const double MapMinY=(-(Simulator::AIRSPACE_SIZE/2) + Aircraft_Size);

FlightControl::FlightControl()
{
    //Iinitally the aircraft is within the airspace
    withinAirspace_=true;
    angular_v=0.0;
    linear_v=Simulator::V_MAX;
}

FlightControl::~FlightControl()
{

}
double FlightControl::getAngular_V()
{
    return angular_v;
}

double FlightControl::getLinear_V()
{
    return linear_v;
}


bool FlightControl::withinAirspace()
{
    return withinAirspace_;
}

int FlightControl::WallInterceptCheck(Pose &air_pose)
{
    //Right Wall
    if(air_pose.position.x>MapMaxX)
    {
        withinAirspace_=false;
        return 1;
    }
    //Left Wall
    else if(air_pose.position.x<MapMinX)
    {
        withinAirspace_=false;
        return 2;
    }
    //Top Wall
    else if(air_pose.position.y>MapMaxY)
    {
        withinAirspace_=false;
        return 3;
    }
    //Bottom Wall
    else if(air_pose.position.y<MapMinY)
    {
        withinAirspace_=false;
        return 4;
    }
    else
    {
        //withinAirspace_=true;
        return 0;
    }

}

void FlightControl::AircraftInitialisation(Pose &air_pose)
{
    //Obtaining the orientation of the aircraft in real time
    double air_angle=tf::quaternionToYaw(air_pose.orientation);


    linear_v=Simulator::V_MAX;
    angular_v=0;

    // Intercepting with Right wall 1
    if ((WallInterceptCheck(air_pose)==1) && (air_angle<=(90*M_PI/180)) && (air_angle>=0))
    {

                        linear_v=Simulator::V_TERM;
                        angular_v=OMEGA_MAX;
                        withinAirspace_=true;


    }
    // Intercepting with Right wall 2
    else if ((WallInterceptCheck(air_pose)==1) && (air_angle<(360*M_PI/180)) && (air_angle>=(270*M_PI/180)) && (withinAirspace_==false))
    {

                        linear_v=Simulator::V_TERM;
                        angular_v=-OMEGA_MAX;
                        withinAirspace_=true;


    }

    // Intercepting with Top wall 1
    else if ((WallInterceptCheck(air_pose)==3) && (air_angle<=(180*M_PI/180)) && (air_angle>90*M_PI/180))
    {

        linear_v=Simulator::V_TERM;
        angular_v=OMEGA_MAX;
        withinAirspace_=true;
    }
    // Intercepting with Top wall 2
    else if ((WallInterceptCheck(air_pose)==3) && (air_angle<=(90*M_PI/180)) && (air_angle>=0))
    {

        linear_v=Simulator::V_TERM;
        angular_v=-OMEGA_MAX;
        withinAirspace_=true;
    }

    //Intercepting with Left Wall 1
    else if ((WallInterceptCheck(air_pose)==2) && (air_angle<=(270*M_PI/180)) && (air_angle>=(180*M_PI/180)) && (withinAirspace_==false))
    {

        linear_v=Simulator::V_TERM;
        angular_v=OMEGA_MAX;
        withinAirspace_=true;
    }
    //Intercepting with Left Wall 2
    else if ((WallInterceptCheck(air_pose)==2) && (air_angle<=(180*M_PI/180)) && (air_angle>=(90*M_PI/180)) && (withinAirspace_==false))
    {

        linear_v=Simulator::V_TERM;
        angular_v=-OMEGA_MAX;
        withinAirspace_=true;
    }
    //Intercepting with Bottom Wall 1
    else if ((WallInterceptCheck(air_pose)==4) && (air_angle<=(360*M_PI/180)) && (air_angle>(270*M_PI/180)) && (withinAirspace_==false))
    {
        linear_v=Simulator::V_TERM;
        angular_v=OMEGA_MAX;
        withinAirspace_=true;
    }
    //Intercepting with Bottom Wall 2
    else if ((WallInterceptCheck(air_pose)==4) && (air_angle<=(360*M_PI/180)) && (air_angle>(270*M_PI/180)) && (withinAirspace_==false))
    {
        linear_v=Simulator::V_TERM;
        angular_v=-OMEGA_MAX;
        withinAirspace_=true;
    }



}





void FlightControl::PurePursuit(const RangeBearingStamped &target, Pose air_pose)
{


    double K=0.95;
    if (withinAirspace_==true)
    {
        if (target.bearing>5*(M_PI/180) && target.bearing<=M_PI)
        {
            linear_v=Simulator::V_TERM/K;
            angular_v=OMEGA_MAX*K;
        }
        else if(target.bearing>M_PI && target.bearing<=355*(M_PI/180))
        {
            linear_v=Simulator::V_TERM/K;
            angular_v=-OMEGA_MAX*K;
        }
        else {
            linear_v=Simulator::V_MAX;
            angular_v=0;
        }
    }
    else
    {
       withinAirspace_=false;
    }
}

Containers::TimerContainer FlightControl::getTimedBogies()
{
    return time_vectors;
}

std::vector<double> FlightControl::getTimeStamps()
{
    return timestamps;
}

void FlightControl::calculateRelativeVelocity(std::vector<RangeVelocityStamped> velocities, std::vector<RangeBearingStamped> bearings,double v)
{

    double a,b,c,x1,x2, v_a,v_b, theta, determinant,s2, realPart, imaginaryPart, interceptTime;
    double a2,b2,c2,v_t,s,p_t,determinant2, t1,t2;
    FlightControl aircraft;
    t1=0;
    t2=0;
    time_vectors.bogie_vector_=bearings;
    std::vector<double> Timestamps;
    std::vector<double> velocities_vector_;
    //Check whether velocity is different from the terminal velocity, minimising unstable results in quadratic equations
     if(v!=Simulator::V_TERM)
     {

      // Matching the vecto sizes so we dont get an exception error ->mismatching vector sizes
      if(velocities.size()==bearings.size())
      {

        for(unsigned int i=0; i<velocities.size(); i++)
        {


            v_a=v;
            v_b=velocities.at(i).velocity;
            theta=bearings.at(i).bearing;

            // Calculating the roots of a quadratic equation
            // ax^2+bx+c, where
            //a=1
            //b=2*(velocity of aircraft)*bogie_bearing
            //c=(velocity of aircraft)^2-(velocity of bogie)^2
            //The roots of the quadratic equation provides us with the relative velocity of the aircraft to the bogies
            a=1;
            b=2*v_a*cos(theta);
            c=pow(v_a,2)-pow(v_b,2);

            determinant=pow(b,2)-4*a*c;
            // Two real and not the same roots
            if(determinant>0)
            {
                x1=(-b+sqrt(determinant))/(2*a);
                x2=(-b-sqrt(determinant))/(2*a);
                if(x1>x2)
                {
                    //Here the roots of the equation reprecent the relative velocity
                    v_t=abs(x1);
                    velocities_vector_.push_back(v_t);
                }
                else {
                    v_t=abs(x2);
                    velocities_vector_.push_back(v_t);
                }
            }
            else if(determinant==0)
            {
                x1=-b/(2*a);
                v_t=abs(x1);
                velocities_vector_.push_back(v_t);
            }
            else {
                realPart = -b/(2*a);
                imaginaryPart =sqrt(-determinant)/(2*a);
                v_t=sqrt(pow(realPart,2)+pow(imaginaryPart,2));
                velocities_vector_.push_back(v_t);

            }
            if (v_t<=0)
            {
                interceptTime=1;
                timestamps.push_back(interceptTime);
            }
            else {
                interceptTime=bearings.at(i).range/v_t;
                timestamps.push_back(interceptTime);

            }


         }
       }
     }
     for (unsigned int j=0; j<velocities_vector_.size(); j++)
        {


            if(velocities_vector_.at(j)<=0)
            {
                interceptTime=1;
                timestamps.push_back(interceptTime);

            }
            else {
                interceptTime=bearings.at(j).range/velocities_vector_.at(j);
                timestamps.push_back(interceptTime);

            }
        }
    //Proceeding with the calculation of the dot product to determine the time to intercept for each bogie
    for(unsigned int i=0; i<time_vectors.bogie_vector_.size(); i++)
    {
        cout << "Time t("<<i<<")="<<time_vectors.timetointerept_vector.at(i)<<endl;
    }
        s=v;
        p_t=100; //Here p_t is the look ahead point, an arbitary value of 100 metres has been selected

        a2=pow(v_t,2)-pow(v_b,2);
        b2=2*v_t*p_t;
        c2=pow(p_t,2);

       determinant2=pow(b2,2)-4*a2*c2;

       if(t1>t2)
       {
           Timestamps.push_back(t1);
       }
       else {
           Timestamps.push_back(t2);
       }
        if(fabs(t1 - 0) < 1e-6)
        {
            Timestamps.push_back(t1);
        }
        else if(fabs(t2 - 0) < 1e-6)
        {
            Timestamps.push_back(t2);
        }


    //Finally the Timestamps could be vied by printing this out
    //However due to unstable readings on the sim->testPose caused mainly from the roots of the quadratic and dot product equations
    //Decided not to include this method and focus on the method described in the AdvancedPathPlanning class
    for (unsigned j=0; j<timestamps.size(); j++)
    {

        //std::cout<<"t("<<j<<")="<<Timestamps.at(j)<<std::endl;
    }

}



