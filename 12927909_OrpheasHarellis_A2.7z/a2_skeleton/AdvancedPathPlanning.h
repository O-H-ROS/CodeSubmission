/*! @file AdvancedPathPlanning.h
 *
 *  @brief Advanced Game Mode Class
 *
 *  This header and its structures are used to assist in the estimation of moving bogie positions and related data
 *  that will allow for the aircraft to accurately intercept the moving bogies and predict their future location and orientation efficiently.
 *
 *  @author Orpheas K. Harellis
 *  @date 13-10-2021
*/


#ifndef ADVANCEDPATHPLANNING_H
#define ADVANCEDPATHPLANNING_H

#include "simulator.h"
#include <vector>
#include <cmath>


using namespace simulator;


class AdvancedRadar
{
public:

    /**
    * @brief Default constructor
    *
    */
    AdvancedRadar();

    /**
    * @brief Default destructor
    *
    */
    ~AdvancedRadar();

    /**
    * @brief Calculation of a moving target's location, aka Extrapolation in time.
    * It computes the speed of the bogies from a set of two points, calculates and time-range Proportional offset
    * This allows for the accurate calculation of the future bogie pose, inlcuding its position and orientation
    * @param Pose friendly aircraft, vector of RangeBearingStamped of bogies, long Time for calculations related to utest
    */
    void locateAdvancedTargets(Pose, std::vector<RangeBearingStamped>, long);

    /**
    * @brief Getter function for the future location of the bogies to be used in pure pursuit
    * @return vector of Points
    */
    std::vector<Point> getGoals();

    /**
    * @brief Getter function for the future Pose of the bogies to be used in sim->TestPose
    * @return vector of Poses
    */
    std::vector<Pose> getFuture();



    /**
     * @brief Calculates the scalar Velocity of a bogie
     *
     * @param First point location, Second point location and long timestamp where the second scan of points occurred
     * @return scalar velocity (m/s)
     */
    double calculateScalarVelocity(Point first_scan, Point second_scan, long TimeInFuture);

    /**
    * @brief Getter function for the future x coordinate of a bogie
    * @return x coordinate
    */
    double getXInFuture();

    /**
    * @brief Getter function for the future y coordinate of a bogie
    * @return y coordinate
    */
    double getYInFuture();


    /**
    * @brief Obtains the rangebearing data
    * Based on the way the advanced radar location finder is structured, the bogies are sorted based on the range and time at the same time.
    * For more information please see "locateAdvancedTargets"
    * @param vector of stamped range bearing data.
    */
    void setAdvancedBogies(std::vector<RangeBearingStamped> &data);
private:

    std::vector<Pose>  previous_bg_pose;
    std::vector<Pose> future_vector_pose;
    std::vector<Point> goals_;
    Pose future_bg_pose;
    double targetAngle;
    std::vector<RangeBearingStamped> friendly_radar_data;
    std::vector<std::pair<double,double>> friendly_radar_;
    std::vector<std::pair<double,double>> velocities_;
    std::vector<std::pair<double,double>> positionsInFuture;
    double xInFuture;
    double yInFuture;
    double v_scalar;


};




#endif //ADVANCEDPATHPLANNING_H
