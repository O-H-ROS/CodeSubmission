/*! @file BasicPathPlanning.h
 *
 *  @brief Flight Controller
 *
 *  This header and its structures are used to assist in the aircrafts movement within the airspace, inluding
 *  1. Boundary Avoidance
 *  2. P control
 *  3. Target finding
 *
 *  @author Orpheas K. Harellis
 *  @date 13-10-2021
*/



#ifndef BASICPATHPLANNINGCOPY_H
#define BASICPATHPLANNINGCOPY_H



#include "aircraft.h"
#include "timer.h"
#include "simulator.h"
#include "tf.h"
#include "BasicPathPlanning.h"
#include <condition_variable>

#include <vector>
#include <cmath>

using namespace simulator;
using namespace geometry_msgs;


class FlightControl
{

public:
    /**
    * @brief Default constructor
    *
    */
    FlightControl();

    /**
    * @brief Default destructor
    *
    */
    ~FlightControl();

    /**
    * @brief Getter function for the angular velocity
    * It is then used in sim->controlFriendly
    * @return double
    */
    double getAngular_V();

    /**
    * @brief Getter function for the linear velocity
    * It is then used in sim->controlFriendly
    * @return double
    */
    double getLinear_V();





    /**
    * @brief Check whether the aircraft is within the airspace
    *
    * @return true if aircraft is withing the airspace
    */
    bool withinAirspace();

    /**
     * @brief Compares the pose of the friendly location to determine whether it has intersected with a wall/boundary of the airspace
     * @param Pose of friendly aircraft
     * @return int based on the wall intersection
     */
    int WallInterceptCheck(Pose &air_pose);

    /**
     * @brief Initialiases the aircraft and ensures its position is maintained with the airspace boundaries
     * @param Pose of friendly aircraft
     */
    void AircraftInitialisation(Pose &air_pose);

    /**
     * @brief Locates and chases bogies, allows for proportional control
     * @param Pose of friendly aircraft and stamped range/bearing of the target bogie
     */
    void PurePursuit(const RangeBearingStamped &, Pose);

    /**
     * @brief Calculates the relative velocity between the bogies and the aircraft via quadratic equations and dot product,
     * It then provides timestamps based on the time to intercept
     * @param Velocities vector of bogies, vector of range/bearing of bogies and v for the aircraft velocity
     */
    void calculateRelativeVelocity(std::vector<RangeVelocityStamped> velocities, std::vector<RangeBearingStamped> bearings,double v);


    /**
     * @brief Getter for localizing the bogies based on the closest time to intercept
     * @param Unfortunately, decided not to implement last minute as the quadratic equations produced strong curtosis on the test poses
     * @return A container which includes a vector of range/bearings and time to intercept
     */
    Containers::TimerContainer getTimedBogies();

    /**
     * @brief Getter for the time-to-intercept method,
     * @param Unfortunately, decided not to implement last minute as the quadratic equations produced strong curtosis on the test poses
     * @return Vector of time stamps
     */
    std::vector<double> getTimeStamps();





private:
    double angular_v;                           /*!< Friendly Aircraft angular speed */
    double linear_v;                            /*!< Friendly Aircraft linear speed */
    bool withinAirspace_;                       /*!< True or false dependent on whether friendly is within the designated airspace */
    Containers::TimerContainer time_vectors;    /*!< Container for the storage and usage of bogie vectors and their corresponding time to intercept vectors */
    std::vector<double> timestamps;             /*!< Vector of time stamps, includes the time to intercept from the friendly aircraft to bogie */

};


#endif //BASICPATHPLANNING_H
