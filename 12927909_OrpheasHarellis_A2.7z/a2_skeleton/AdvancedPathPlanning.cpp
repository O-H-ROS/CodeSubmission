#include "AdvancedPathPlanning.h"
#include <cmath>

AdvancedRadar::AdvancedRadar()
{
    // Resizing the vectors so we dont get exception error--missing size of vecot
    previous_bg_pose.resize(4);
    future_vector_pose.resize(4);
    goals_.resize(4);
}

AdvancedRadar::~AdvancedRadar()
{

}

void AdvancedRadar::locateAdvancedTargets(Pose sim_pose, std::vector<RangeBearingStamped> air_scan, long TimeInFuture)
{
    // Default pose of the friendly aircraft pose
    Pose pose=sim_pose;
    //Placeholders to be used to pass on the poses
    double x5,y5;
    //Calculation of the friendly orientation
    double friendly_orientation=tf::quaternionToYaw(pose.orientation);
    double x=pose.position.x;
    double y=pose.position.y;
    //Second bubble sorting to make sure
    std::vector<RangeBearingStamped> bogies=air_scan;
    for (size_t i = 0; i < bogies.size() - 1; ++i) {
            for (size_t j = 0; j < bogies.size() - i - 1; ++j) {
                if (bogies.at(j).range > bogies.at(j + 1).range)
                    std::swap(bogies.at(j), bogies.at(j + 1));
            }
        }

    //Creation of a proportional control for the bogie location based on the distance offset and the friendly's speed
    // Something close to relative speed
    double distanceOffset=8000;
    double timeOffset=distanceOffset/Simulator::V_MAX;
    //bogies.clear();
    for(unsigned int i=0; i<bogies.size(); i++)
    {
        Pose f_bgPose;
        double bogie2friendlyDistance=bogies.at(i).range;
        double bogie2friendlyBearing=bogies.at(i).bearing;
        double abso_bearing=fmod((bogie2friendlyBearing+friendly_orientation),(2*M_PI));
        Pose bogie_pose;
        bogie_pose.position.x=x+bogie2friendlyDistance*cos(abso_bearing);
        bogie_pose.position.y=y+bogie2friendlyDistance*sin(abso_bearing);
        double x1=bogie_pose.position.x-previous_bg_pose.at(i).position.x;
        double y1=bogie_pose.position.y-previous_bg_pose.at(i).position.y;
        bogie_pose.orientation=tf::yawToQuaternion(fmod((atan2(y1,x1)),(2*M_PI)));


        double TimeProportionality=bogie2friendlyDistance/distanceOffset;

        //Calculates and stores the velocities based on the radar's refresh rate
        double veloX=(bogie_pose.position.x-previous_bg_pose.at(i).position.x)/0.01;
        double veloY=(bogie_pose.position.y-previous_bg_pose.at(i).position.y)/0.01;

        //Calculation of a position in the future based on the provided location,velocity and time in future
        xInFuture=bogie_pose.position.x+veloX*(0.01+TimeInFuture);
        yInFuture=bogie_pose.position.y+veloY*(0.01+TimeInFuture);

        //Calculation of the future bogie pose, inlcuding position and orientation based on time and range
        // The future bogie pose will later be used to determine the sim->testPoe
        f_bgPose.position.x=bogie_pose.position.x+veloX*(0.01+TimeProportionality);
        f_bgPose.position.y=bogie_pose.position.y+veloY*(0.01+TimeProportionality);
        f_bgPose.position.z=0;
        f_bgPose.orientation=bogie_pose.orientation;

        future_vector_pose.at(i)=f_bgPose;

        //Storing and updating the previous bogie pose that is being used to calculate velocity and position
        previous_bg_pose.at(i)=bogie_pose;
        //double abso_bearing_b2f=atan((f_bgPose.position.y-sim_pose.position.y)/(f_bgPose.position.x-sim_pose.position.x));
        goals_.at(i).x=f_bgPose.position.x;
        goals_.at(i).y=f_bgPose.position.y;
        goals_.at(i).z=0;
        //positionsInFuture.at(i)=(std::make_pair(xInFuture,yInFuture));
    }

    //Placeholder values to be used within the utest section of this assignment
    x5=future_vector_pose.at(0).position.x;
    y5=future_vector_pose.at(0).position.y;
}

double AdvancedRadar::calculateScalarVelocity(Point first_scan, Point second_scan, long TimeInFuture)
{
    //Calculation of scalar velocity given two points and time from Velocity=Distance/Time;
    double veloX=(first_scan.x-second_scan.x)/TimeInFuture;
    double veloY=(first_scan.y-second_scan.y)/TimeInFuture;
    v_scalar=sqrt(pow(veloX,2)+pow(veloY,2));
    return v_scalar;
}

std::vector<Pose> AdvancedRadar::getFuture()
{
    return future_vector_pose;
}

double AdvancedRadar::getXInFuture()
{
    return xInFuture;
}

double AdvancedRadar::getYInFuture()
{
    return yInFuture;
}



void AdvancedRadar::setAdvancedBogies(std::vector<RangeBearingStamped> &data)
{
    //Container to bubble sort the data in ascending order based on the new readings provided from the extrapolation
    std::vector<RangeBearingStamped> friendly_radar=data;
    //This method is basically performing time to impact comparison as the range is closely associated with the time
    // Please see "locateAdvancedTargets"
    for (size_t i = 0; i < friendly_radar.size() - 1; ++i) {
            for (size_t j = 0; j < friendly_radar.size() - i - 1; ++j) {
                if (friendly_radar.at(j).range > friendly_radar.at(j + 1).range)
                    std::swap(friendly_radar.at(j), friendly_radar.at(j + 1));
            }
        }
    friendly_radar_data=friendly_radar;
    for (unsigned int i=0; i<friendly_radar.size(); i++)
    {
        friendly_radar_.push_back(std::make_pair(friendly_radar.at(i).range,friendly_radar.at(i).bearing));
    }
}

std::vector<Point> AdvancedRadar::getGoals()
{
    return goals_;
}
