/*! @file Threading.h
 *
 *  @brief Threading class
 *
 *  This header includes all the relevant data and structures to ensure proper thread management
 *
 *  @author Orpheas K. Harellis
 *  @date 13-10-2021
*/

#ifndef THREADING_H
#define THREADING_H





#include "aircraft.h"
#include "timer.h"
#include "simulator.h"
#include "tf.h"
#include "types.h"
#include "BasicPathPlanning.h"
#include "AdvancedPathPlanning.h"
#include <condition_variable>
#include <mutex>
#include "BasicPathPlanningcopy.h"


using namespace simulator;
using namespace geometry_msgs;


class Threading
{

public:
    /**
    * @brief Default constructor
    *
    */
    Threading();

    /**
    * @brief Default destructor
    *
    */
    ~Threading();


    /**
     * @brief Control thread is responsible for controlling the test poses of basic game mode and locating the stationary targets
     * @param shared pointer sim, object of Flight controller, object of BasicRadar and object of Thread
     */
    void ctrl(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar, Threading &data);

    /**
     * @brief Control thread is responsible for controlling the test poses of advanced game mode and locating the moving targets
     * @param shared pointer sim, object of Flight controller, object of BasicRadar and object of Thread
     */
    void Advancedctrl(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar,AdvancedRadar &AdvRadar, Threading &data, Timer &tim);


    /**
     * @brief Process thread is the processing core of the aircraft, it ensures the aircraft is limited within the airspace and enables P controller
     * @param shared pointer sim, object of Flight controller and pose of friendly aircraft
     */
    void prcs(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, Pose air_pose);

    /**
     * @brief Data acquiring, processing and updating the startionary bogie target locations for the basic game mode
     * @param shared pointer sim, object of Basic Radar
     */
    void DAQ_TH(const std::shared_ptr<Simulator> &sim, BasicRadar &Radar);

    /**
     * @brief Data acquiring, processing and updating the moving bogie target locations for the advanced game mode
     * @param shared pointer sim
     */
    void AdvancedDAQ_TH(const std::shared_ptr<Simulator> &sim, BasicRadar &Radar);




private:
    std::mutex mu_;                                         /*!< Mutex variable for thread management */
    std::condition_variable cv_;                            /*!< Condition variable for thread management */
    Containers::OnBoardRadar friendly_radar2_;              /*!< Thread safe container */
    Containers::OnBoardRadar new_targets2;                  /*!< Thread safe container */
    RangeBearingStamped closest_bogie;                      /*!< stamped range/bearing for the closest_bogie */
    Pose simPose;                                           /*!< Friendly aircraft pose */
    Containers::Friendly_air friendly_air;                  /*!< Thread safe container  for the friendly aircraft*/
    bool checkReady;                                        /*!< Boolean variable for proper thread management */
    std::vector<RangeBearingStamped> updatedGoals;          /*!< Vector that contains the bogies' range/bearings for advanced mode */
    std::vector<Pose> f_pose_vector;                        /*!< Vector that contains the predicted/future bogies poses */
    std::vector<RangeBearingStamped> stationary_bogies;     /*!< Vector that contains the bogies' range/bearings for basic mode */



};





#endif //THREADING_H
