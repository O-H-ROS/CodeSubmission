#include "gtest/gtest.h"
#include <iostream>

#include <vector>

// Student defined libraries, for instance
#include "AdvancedPathPlanning.h"
#include "BasicPathPlanning.h"


#include "types.h"


//==================== UNIT TEST START ====================//


TEST(BogieTest, DetermineVelocity)
{

    AdvancedRadar AdvRadar;
    long SecondsInFuture=3;
    Point InitialScan = {164.36,200,0};
    Point SecondaryScan = {220,500,0};
    double scalar_velocity=AdvRadar.calculateScalarVelocity(InitialScan,SecondaryScan,SecondsInFuture);

    EXPECT_NEAR(101.705,scalar_velocity, 1e-3);

}

TEST(BogieTest, ExtrapolationInTime)
{

    AdvancedRadar AdvRadar;

    long SecondsInFuture=3;
    Pose aircraft;

    aircraft.position = {0,0,0};
    aircraft.orientation = tf::yawToQuaternion(0.28);

    {
        Point bogie = {164.36,-1625.53,0};

        std::vector<RangeBearingStamped> air_scan;

        RangeBearingStamped rb = {5.41,4.53316,0};
        air_scan.push_back(rb);


        AdvRadar.locateAdvancedTargets(aircraft,air_scan,SecondsInFuture);


        double xInFuture=AdvRadar.getXInFuture();
        double yInFuture=AdvRadar.getYInFuture();

        EXPECT_NEAR(bogie.x,xInFuture,0.5);
        EXPECT_NEAR(bogie.y,yInFuture,0.5);
    }

}



int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);

  return RUN_ALL_TESTS();
}
