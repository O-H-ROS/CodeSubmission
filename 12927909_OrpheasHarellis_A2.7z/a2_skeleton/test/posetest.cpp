#include "gtest/gtest.h"
#include <iostream>

#include <vector>

// Student defined libraries, for instance
//#include "flightplanner.h"


#include "types.h"

#include "BasicPathPlanning.h"

//==================== UNIT TEST START ====================//

TEST(PoseTest, LocalToGlobal)
{
    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the origin
    aircraft.position = {0,0,0};
    aircraft.orientation = tf::yawToQuaternion(0.785398);
    {
        Point bogie = {3171.34,-4574.67,0};
        std::vector<RangeBearingStamped> bogies_vector;

        RangeBearingStamped rb = {5566.41,4.53316,0};
        bogies_vector.push_back(rb);

        basicRadar.locateTargets(aircraft,bogies_vector);

        Point bogieComputed;
        bogieComputed.x=basicRadar.getTargetOfInterest().at(0).first;
        bogieComputed.y=basicRadar.getTargetOfInterest().at(0).second;
        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }
}

TEST(PoseTest, LocalToGlobal_2)
{
    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Top Right Quadrant
    aircraft.position = {1800,1800,0};
    aircraft.orientation = tf::yawToQuaternion(1.2);
    {
        Point bogie = {-1128.56,-2003.09,0};
        std::vector<RangeBearingStamped> bogies_vector;

        RangeBearingStamped rb = {4800,2.85618,0};
        bogies_vector.push_back(rb);

        basicRadar.locateTargets(aircraft,bogies_vector);

        Point bogieComputed;
        bogieComputed.x=basicRadar.getTargetOfInterest().at(0).first;
        bogieComputed.y=basicRadar.getTargetOfInterest().at(0).second;
        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }
}

TEST(PoseTest, LocalToGlobal_3)
{
    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Top Left Quadrant
    aircraft.position = {-1800,1800,0};
    aircraft.orientation = tf::yawToQuaternion(0.28);
    {
        Point bogie = {-5567.05,4261.56,0};
        std::vector<RangeBearingStamped> bogies_vector;

        RangeBearingStamped rb = {4500,2.2828,0};
        bogies_vector.push_back(rb);

        basicRadar.locateTargets(aircraft,bogies_vector);

        Point bogieComputed;
        bogieComputed.x=basicRadar.getTargetOfInterest().at(0).first;
        bogieComputed.y=basicRadar.getTargetOfInterest().at(0).second;
        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }
}

TEST(PoseTest, LocalToGlobal_4)
{
    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Bottom Left Quadrant
    aircraft.position = {-1800,-2000,0};
    aircraft.orientation = tf::yawToQuaternion(0.28);
    {
        Point bogie = {-2034.39,-1846.83,0};
        std::vector<RangeBearingStamped> bogies_vector;

        RangeBearingStamped rb = {280,2.2828,0};
        bogies_vector.push_back(rb);

        basicRadar.locateTargets(aircraft,bogies_vector);

        Point bogieComputed;
        bogieComputed.x=basicRadar.getTargetOfInterest().at(0).first;
        bogieComputed.y=basicRadar.getTargetOfInterest().at(0).second;
        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }
}

TEST(PoseTest, LocalToGlobal_5)
{
    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Bottom Right Quadrant
    aircraft.position = {1000,-1800,0};
    aircraft.orientation = tf::yawToQuaternion(2.4);
    {
        Point bogie = {1092.65,-1883.90,0};
        std::vector<RangeBearingStamped> bogies_vector;

        RangeBearingStamped rb = {125,28.28,0};
        bogies_vector.push_back(rb);

        basicRadar.locateTargets(aircraft,bogies_vector);

        Point bogieComputed;
        bogieComputed.x=basicRadar.getTargetOfInterest().at(0).first;
        bogieComputed.y=basicRadar.getTargetOfInterest().at(0).second;
        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);
    }
}


TEST(PoseTest, GlobalToLocal)
{

    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the origin
    aircraft.position = {0,0,0};
    aircraft.orientation = tf::yawToQuaternion(0.785398);
    {
        Point bogie = {-3288.52,-2516.65,0};
        RangeBearingStamped rb = {4141,3.0094,0};

        Point bogieComputed = basicRadar.local2Global(rb,aircraft);

        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);

    }

}

TEST(PoseTest, GlobalToLocal_2)
{

    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Top Right Quadrant
    aircraft.position = {1800,1800,0};
    aircraft.orientation = tf::yawToQuaternion(1.2);
    {
        Point bogie = {-1128.56,-2003.09,0};
        RangeBearingStamped rb = {4800,2.85618,0};

        Point bogieComputed = basicRadar.local2Global(rb,aircraft);

        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);

    }

}

TEST(PoseTest, GlobalToLocal_3)
{

    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Top Left Quadrant
    aircraft.position = {-1800,2800,0};
    aircraft.orientation = tf::yawToQuaternion(0.28);
    {
        Point bogie = {-5567.05,5261.56,0};
        RangeBearingStamped rb = {4500,2.2828,0};

        Point bogieComputed = basicRadar.local2Global(rb,aircraft);

        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);

    }

}

TEST(PoseTest, GlobalToLocal_4)
{

    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Bottom Left Quadrant
    aircraft.position = {-1800,-2000,0};
    aircraft.orientation = tf::yawToQuaternion(0.28);
    {
        Point bogie = {-2034.39,-1846.83,0};
        RangeBearingStamped rb = {280,2.2828,0};

        Point bogieComputed = basicRadar.local2Global(rb,aircraft);

        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);

    }

}

TEST(PoseTest, GlobalToLocal_5)
{

    BasicRadar basicRadar;
    Pose aircraft;
    // Aircraft location is at the Bottom Right Quadrant
    aircraft.position = {1000,-1800,0};
    aircraft.orientation = tf::yawToQuaternion(2.4);
    {
        Point bogie = {1092.65,-1883.90,0};
        RangeBearingStamped rb = {125,28.28,0};

        Point bogieComputed = basicRadar.local2Global(rb,aircraft);

        EXPECT_NEAR(bogie.x,bogieComputed.x,0.5);
        EXPECT_NEAR(bogie.y,bogieComputed.y,0.5);

    }

}


int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);

  return RUN_ALL_TESTS();
}
