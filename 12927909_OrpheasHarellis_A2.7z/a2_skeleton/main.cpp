#include <thread>
#include <vector>
#include <iostream>
#include "simulator.h"
#include "BasicPathPlanning.h"
#include "Threading.h"
#include <algorithm>
#include <bits/stdc++.h>
#include "BasicPathPlanningcopy.h"
#include <condition_variable>
#include <climits>
#include <mutex>

using geometry_msgs::Pose;
using geometry_msgs::Point;
using geometry_msgs::RangeBearingStamped;
using geometry_msgs::RangeVelocityStamped;
using namespace simulator;





void control_th(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar, Threading &data)
{
    data.ctrl(sim, f_c, Radar, data);

}

void Advcontrol_th(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar,AdvancedRadar &AdvRadar, Threading &data, Timer &tim)
{
    data.Advancedctrl(sim, f_c, Radar,AdvRadar, data, tim);

}

void process_th(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar, Pose air_pose, Threading &data)
{
    data.prcs(sim, f_c, air_pose);
}

void analysisTh(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar, Threading &data)
{
    data.DAQ_TH(sim, Radar);
}

void AdvancedanalysisTh(const std::shared_ptr<Simulator> &sim, FlightControl &f_c, BasicRadar &Radar, Threading &data)
{
    data.AdvancedDAQ_TH(sim, Radar);
}


int main (int argc, char *argv[]) {

std::this_thread::sleep_for(std::chrono::milliseconds(300));


GameMode game_mode = GameMode::BASIC;
//If code is started with --advanced, it will run in advanced mode
std::cout << "Run with: " << argv[0] << " --advanced to run in advanced mode" << std::endl;
if(argc>1){
    if(strcmp (argv[1],"-advanced")){
        std::cout << "Advanced Mode Activated" << std::endl;
        game_mode = GameMode::ADVANCED;
    }
}

std::vector<std::thread> threads;

BasicRadar Radar;
AdvancedRadar AdvRadar;
FlightControl f_c;
Threading data;
Timer tim;

Pose air_pose;

//std::shared_ptr<Simulator> sim(new Simulator());
std::shared_ptr<Simulator> sim(new Simulator(true,game_mode));
threads.push_back(sim->spawn());

if(game_mode==GameMode::ADVANCED)
{
    threads.push_back(std::thread(Advcontrol_th, sim, std::ref(f_c), std::ref(Radar),std::ref(AdvRadar), std::ref(data), std::ref(tim)));
    threads.push_back(std::thread(process_th, sim, std::ref(f_c), std::ref(Radar), air_pose, std::ref(data)));
    threads.push_back(std::thread(AdvancedanalysisTh, sim, std::ref(f_c), std::ref(Radar), std::ref(data)));
}
else {
    threads.push_back(std::thread(control_th, sim, std::ref(f_c), std::ref(Radar), std::ref(data)));
    threads.push_back(std::thread(process_th, sim, std::ref(f_c), std::ref(Radar), air_pose, std::ref(data)));
    threads.push_back(std::thread(analysisTh, sim, std::ref(f_c), std::ref(Radar), std::ref(data)));
}






for (auto &THREADS:threads)
{
    THREADS.join();
}



    return 0;
}
