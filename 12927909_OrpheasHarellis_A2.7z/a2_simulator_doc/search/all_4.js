var searchData=
[
  ['friendly_5fref_5frate',['FRIENDLY_REF_RATE',['../classsimulator_1_1Simulator.html#a6ed76930f7f1efb8396ffd05189ed000',1,'simulator::Simulator']]]
];
